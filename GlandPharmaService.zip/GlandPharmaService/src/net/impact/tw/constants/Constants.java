package net.impact.tw.constants;

import net.impact.tw.helper.PropertyReader;

public class Constants {
	
	public static final String TWS_URL="tws.url";
	public static final String TWS_MAX_CONN="tws.maxconnections";
	public static final String TWS_TIMEOUT="tws.timeout";
	public static final String USER_NAME="user.name";
	public static final String USER_TIMEZONE="user.timezone";
	public static final String USER_PASSWORD="user.password";
	public static final String CACHED_HTTP_CLIENT="CACHED_HTTP_CLIENT";
	public static final String REUSE_HTTP_CLIENT="REUSE_HTTP_CLIENT";
	public static final String ERROR_TER_SESSION="Error in terminating sesssion";
	public static final String SQL_CLASS_NAME="SQL_CLASS_NAME";
	public static final String SQL_CONECTION_STRING="SQL_CONECTION_STRING";
	public static final String SQL_USER="SQL_USER";
	public static final String SQL_PASSWORD="SQL_PASSWORD";
	public static final String PRID="prId";
	
	
	//Parent Project Name.
	public static final String CC_PARENT_PROJECT = "parent.cc.projectname";
	public static final String TCC_PARENT_PROJECT = "parent.tcc.projectname";
	
	//All GridField Variable name
	public static final String COMPIMPACTEDSITEGRID = "compImpactedSite.gridfieldname";
	public static final String BATCH_DETAILS_GRID = "batchdetailsgrid.gridfieldname";
	public static final String CAPA_PLAN_MC_GRID = "capaplanmc.gridfieldname";
	public static final String INV_ACTION_GRID = "invaction.gridfieldname";
	public static final String CAPA_PLAN_RCI_GRID = "capaplanrci.gridfieldname";
	public static final String CFT_ASSESSMENT_GRID = "cft.cftgridfieldname";
	public static final String ACTION_PLAN_GRID = "ap.gridfieldname";
	public static final String ADDITIONAL_ACTION_PLAN_GRID = "addactionplan.gridfieldname";
	public static final String TEMP_ACTION_PLAN_GRID = "tempap.gridfieldname";
	
	//All Child Creation Project Name.
	public static final String COMP_INV_FORM_PROJ = "create.cmpinvform.childpr.projectname";
	public static final String COMP_INV_API_PROJ = "create.cmpinvapi.childpr.projectname";
	public static final String CAPA_PLAN_PROJ = "create.capa.childpr.projectname";
	public static final String INV_ACTION_PROJ = "create.invaction.childpr.projectname";
	public static final String RCI_PROJECT_NAME = "create.rciprjname";
	public static final String CFT_PROJECT_NAME = "create.cftprojname";
	public static final String RA_ASSESSMENT_PROJECT_NAME = "create.raassessprjname";
	public static final String ACTION_ITEM_PROJECT_NAME = "create.ai.childpr.projectname";
	public static final String TCC_RA_ASSESSMENT_PROJECT_NAME = "create.tccraassessprjname";
	
	//All Trackwise SelectionField Attribute.
	public static final String SITE_NAME = "tws.sitename";
	public static final String DIVISION = "tws.division";
	public static final String SITE_CODE = "tws.sitecode";
	public static final String CAPA_TYPE = "tws.capatype";
	public static final String PROJECT = "tws.project";
	public static final String SOURCE_OF_CAPA = "tws.sourceofcapa";
	public static final String CAPA_DEPARTMENT = "tws.capadept";
	public static final String CAPA_PLAN_REQ = "tws.capaplanreq";
	public static final String RESPONSIBLE_DEPT = "tws.respondept";
	public static final String ORIGINATING_DEPT = "tws.originatingdept";
	public static final String CAPA_DEPT = "tws.capadept";
	public static final String CAPA_REQUIRED = "tws.caparequired";
	public static final String CFT_REQUIRED = "tws.cftassessreq";
	public static final String RA_ASSESSMENT_REQUIRED = "tws.raassessreq";
	public static final String ACTION_PLAN_DEPT = "tws.actionplandept";
	public static final String ACTION_ITEM_DEPT = "tws.actionitemdept";
	
	
	//All Trackwise StringField Attribute.
	public static final String SHORT_DESC = "tws.shortdesc";
	public static final String HID_EXT_DOC_NO = "tws.extDocNo";
	public static final String HID_REV_DOC_NO = "tws.revDocNo";
	
	//All TrackWise MultiPersonField Attribute.
	public static final String QA_REVIEWER = "tws.qareviewer";
	public static final String CQA_REVIEWER = "tws.cqareviewer";
	public static final String QA_HOD = "tws.qahod";
	public static final String RESP_DEPT_HOD = "tws.respdepthod";
	public static final String QA_COORDINATOR = "tws.qacoordinator";
	public static final String ASSIGNEE_PERSON = "tws.assigneeperson";
	public static final String CFT_ASSESS_TEAM = "tws.cftassteam";
	public static final String RA_ASSESSMENT_REVIEWER = "tws.raassessreviwer";
	public static final String QA_INCHARGE = "tws.qaincharge";
	public static final String ACTION_IMPLEMENTER = "tws.actionimple";
	public static final String IMPL_DEPT_HOD = "tws.impldepthod";
	
	
								
	//All TrackWise PersonField Attribute.
	public static final String COMP_IMPACTED_SITE_OWNER = "tws.compimpsiteowner";
	public static final String INITIATOR = "tws.initiator";
	public static final String CC_INITIATOR = "tws.ccinitiator";
	
	//All TrackWise DateField Attribute.
	public static final String TARGET_DATE = "tws.targetdate";
	public static final String AI_TARGET_COMPLETION_DATE = "tws.aitargercompdate";
	
	//All TrackWise NumberField Attribute.
	public static final String PARENT_ID = "tws.parentId";
	
	
	//DepartmentList.
	public static final String DEPARTMENT_1 = "tws.dept1";
	public static final String DEPARTMENT_2 = "tws.dept2";
	public static final String DEPARTMENT_3 = "tws.dept3";
	public static final String DEPARTMENT_4 = "tws.dept4";
	public static final String DEPARTMENT_5 = "tws.dept5";
	public static final String DEPARTMENT_6 = "tws.dept6";
	public static final String DEPARTMENT_7 = "tws.dept7";
	public static final String DEPARTMENT_8 = "tws.dept8";
	public static final String DEPARTMENT_9 = "tws.dept9";
	public static final String DEPARTMENT_10 = "tws.dept10";
	public static final String DEPARTMENT_11 = "tws.dept11";
	public static final String DEPARTMENT_12 = "tws.dept12";
	public static final String DEPARTMENT_13 = "tws.dept13";
	public static final String DEPARTMENT_14 = "tws.dept14";
	public static final String DEPARTMENT_15 = "tws.dept15";
	public static final String DEPARTMENT_16 = "tws.dept16";
	public static final String DEPARTMENT_17 = "tws.dept17";
	public static final String DEPARTMENT_18 = "tws.dept18";
	public static final String DEPARTMENT_19 = "tws.dept19";
	public static final String DEPARTMENT_20 = "tws.dept20";
	
	//Trackwise Action Item Grid Name.
	public static final String ACTION_ITEM_GRID_1 = "tws.aigrid1";
	public static final String ACTION_ITEM_GRID_2 = "tws.aigrid2";
	public static final String ACTION_ITEM_GRID_3 = "tws.aigrid3";
	public static final String ACTION_ITEM_GRID_4 = "tws.aigrid4";
	public static final String ACTION_ITEM_GRID_5 = "tws.aigrid5";
	public static final String ACTION_ITEM_GRID_6 = "tws.aigrid6";
	public static final String ACTION_ITEM_GRID_7 = "tws.aigrid7";
	public static final String ACTION_ITEM_GRID_8 = "tws.aigrid8";
	public static final String ACTION_ITEM_GRID_9 = "tws.aigrid9";
	public static final String ACTION_ITEM_GRID_10 = "tws.aigrid10";
	public static final String ACTION_ITEM_GRID_11 = "tws.aigrid11";
	public static final String ACTION_ITEM_GRID_12 = "tws.aigrid12";
	public static final String ACTION_ITEM_GRID_13 = "tws.aigrid13";
	public static final String ACTION_ITEM_GRID_14 = "tws.aigrid14";
	public static final String ACTION_ITEM_GRID_15 = "tws.aigrid15";
	public static final String ACTION_ITEM_GRID_16 = "tws.aigrid16";
	public static final String ACTION_ITEM_GRID_17 = "tws.aigrid17";
	public static final String ACTION_ITEM_GRID_18 = "tws.aigrid18";
	public static final String ACTION_ITEM_GRID_19 = "tws.aigrid19";
	public static final String ACTION_ITEM_GRID_20 = "tws.aigrid20";
	
	//Custom String Used In Project.
	public static final String WAIT_TIME_OUT = PropertyReader.getProperty("tws.waittime").trim();
	
	
	//Database SQL Query Variables
	public static final String GET_MULTIPERSON_ROLE = "sqlq.getmultiperson";
	public static final String GET_DEPARTMENT = "sqlq.getdepartment";
	public static final String GET_CHILD_PR = "sqlq.getchildpr";
	
	
	//Database Query For Re-process Mechanism.
	
	public static final String ADD_FAILED_RECORD = "sqlq.addFailedRecord";
	public static final String UPDATE_PROCESSED_RECORD = "sqlq.updateProcessedRecord ";
	public static final String FIND_BY_ID = "sqlq.findById";
	public static final String FIND_PENDING_RECORDS = "sqlq.findPendingRecord";
	public static final String FIND_BY_PRID = "sqlq.findByPRId";
	
	
	//TWS User For Re-Process Mechanism.
	public static final String REPROCESS_USER = "tws.reprocess.user";
	public static final String REPROCESS_PASSWORD = "tws.reprocess.password";
	
}
