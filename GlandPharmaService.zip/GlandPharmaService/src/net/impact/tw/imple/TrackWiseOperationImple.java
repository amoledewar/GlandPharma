package net.impact.tw.imple;

import java.rmi.RemoteException;

import org.apache.log4j.Logger;

import com.sparta.webservices.axis2.TWSException;
import com.sparta.webservices.axis2.TrackWiseStub;
import com.sparta.webservices.axis2.fields.PR;
import com.sparta.webservices.axis2.fields.Util;

import net.impact.tw.dao.RecordReprocessDAO;
import net.impact.tw.dao.TrackWiseOperationDAO;
import net.impact.tw.dto.RecordReprocessEntity;
import net.impact.tw.exception.NotificationException;
import net.impact.tw.helper.GPServiceConnection;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axiom.om.OMNamespace;
import org.apache.log4j.Logger;
import com.sparta.webservices.axis2.TWSException;
import com.sparta.webservices.axis2.TrackWiseStub;
import com.sparta.webservices.axis2.fields.Activity;
import com.sparta.webservices.axis2.fields.ComplexType;
import com.sparta.webservices.axis2.fields.DateField;
import com.sparta.webservices.axis2.fields.DateTimeField;
import com.sparta.webservices.axis2.fields.Field;
import com.sparta.webservices.axis2.fields.GridField;
import com.sparta.webservices.axis2.fields.GridRow;
import com.sparta.webservices.axis2.fields.MultiPersonField;
import com.sparta.webservices.axis2.fields.NumberField;
import com.sparta.webservices.axis2.fields.PR;
import com.sparta.webservices.axis2.fields.Person;
import com.sparta.webservices.axis2.fields.PersonField;
import com.sparta.webservices.axis2.fields.Selection;
import com.sparta.webservices.axis2.fields.SelectionField;
import com.sparta.webservices.axis2.fields.StringField;
import com.sparta.webservices.axis2.fields.Util;
import com.sparta.webservices.client.constants.NameDefault;
import net.impact.tw.constants.Constants;
import net.impact.tw.helper.DBHandler;
import net.impact.tw.helper.GPServiceConnection;
import net.impact.tw.helper.OWSUtil;
import net.impact.tw.helper.PropertyReader;


public class TrackWiseOperationImple implements TrackWiseOperationDAO  {
	
	DBHandler dbHandler = new DBHandler();

	//Connection sqlConn = null;
	Logger logger;
	
	public TrackWiseOperationImple() {
		this.logger = Logger.getLogger((Class) TrackWiseOperationImple.class);
	}
	
	@Override
	public void createADEChild(int prId) {
		
	}

	@Override
	public int createCompInvFormulationChild(int prId,String sessionId,TrackWiseStub tws) throws Exception {
		int newchildPrId = 0;
		try {
			logger.info("OWS_LOG : IN METHOD createCompInvFormulationChild.. SessionId="+sessionId+" PRID :"+prId);
			final PR pr = Util.getPRById(tws, sessionId, prId);
			if (pr != null) {
				final Map<String, Field> fieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) pr);
				final GridField grid = (GridField) fieldMap.get(PropertyReader.getProperty(Constants.COMPIMPACTEDSITEGRID));
				if (grid != null) {
					final GridRow[] gridRows = grid.getGridRows();
					logger.info(("GridRowsLenght : " + gridRows.length));
					if(gridRows != null && gridRows.length>0) {
						List<Integer> childPRIdsList = null;
						Connection sqlConn = dbHandler.getSQLConnection();
						for (int i = 0; i < gridRows.length; ++i) {
							final GridRow gridRow = gridRows[i];
							final Field[] gridFields = gridRow.getFields();
							boolean isCreateChild = true;
							childPRIdsList = dbHandler.getChildPrId(sqlConn, prId);
							final StringField complaintDescRowValue = (StringField) gridFields[0];
							final SelectionField compImpactedSiteNameRowValue = (SelectionField) gridFields[1];
							final PersonField compImpactedSiteOwnerRowValue = (PersonField) gridFields[2];
							if(childPRIdsList != null && childPRIdsList.size()>0) {
								for(int childPrId : childPRIdsList ) {
									final PR existiningChildPr = Util.getPRById(tws, sessionId, childPrId);
									if (existiningChildPr != null) {
										final Map<String, Field> existingChildFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) existiningChildPr);
										SelectionField projectField = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.PROJECT));
										if(projectField != null && projectField.getSelection()!=null && projectField.getSelection().getValue().equals(PropertyReader.getProperty(Constants.COMP_INV_FORM_PROJ))) {
											SelectionField siteNameField = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.SITE_NAME));
											StringField complDescField = (StringField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.SHORT_DESC));
											MultiPersonField compImpSiteOwnerField = (MultiPersonField)existingChildFieldMap.get(PropertyReader.getProperty(Constants.QA_REVIEWER).trim());
											Person compSiteOwnerAry[] = compImpSiteOwnerField.getPersons();
											int compSiteOwnerChildPRValue=0;
											if(compSiteOwnerAry != null && compSiteOwnerAry.length>0) {
												for(int p=0;p<compSiteOwnerAry.length;p++) {
													Person personObj = compSiteOwnerAry[p];
													compSiteOwnerChildPRValue = personObj.getId();
												}
											}else {
												logger.info("OWS_LOG : SITE OWNER ARRAY IS BLANK.!!!");
											}
											if(siteNameField != null && complDescField != null) {
												String siteName = siteNameField.getSelection() != null? siteNameField.getSelection().getValue(): "";
												if(siteName.equals(compImpactedSiteNameRowValue.getSelection().getValue()) && complaintDescRowValue.getValue().equals(complDescField.getValue()) && compImpactedSiteOwnerRowValue.getPerson().getId()==compSiteOwnerChildPRValue) {
													isCreateChild = false;
													logger.info("OWS_MSG : CHILD IS ALREADY CREATED FOR SITE NAME : "+compImpactedSiteNameRowValue+" COMP_DESC :"+complaintDescRowValue+" COMP_SITE_OWNER : "+compImpactedSiteOwnerRowValue);
												}
											}
										}
									}
								}
							}else {
								logger.info("OWS_LOG : CHILD PR IS NOT CREATED YET FOR PRID : "+prId);
							}
							
							if(isCreateChild) {
								//SelectionField divisionField = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.DIVISION));
								//String division = divisionField != null && divisionField.getSelection() != null ? divisionField.getSelection().getValue():"";
								newchildPrId = createCompInvFormulationChild(tws, sessionId, prId,gridFields,sqlConn,fieldMap);
								
							}
							
						}
					}else {
						logger.info("OWS_MSG : Not Grid Row found In Grid Field : "+PropertyReader.getProperty(Constants.COMPIMPACTEDSITEGRID));
					}
				}else {
					logger.info("OWS_MSG : GridField Not found : "+PropertyReader.getProperty(Constants.COMPIMPACTEDSITEGRID));
				}
			}else {
				logger.info("OWS_MSG : PR NOT FOUND FOR PRID : "+prId);
			}
		}catch(TWSException twse) {
			String msg = twse.getMessage();
			logger.info("PRID : "+prId+"OWS_MSG : TWS_EXCEPTION_MSG : "+msg+" FAULT_MSG : "+twse.getFaultMessage());
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(prId,"createCompInvFormulationChild");
			if(!isPRIDExist) {
				addFailedRecord("createCompInvFormulationChild",prId,msg);
			}else {
				logger.info("OWS_LOG : PRID : "+prId+" is already exist in reprocess table.");
			}
		}
		return newchildPrId;
	}


	private int createCompInvFormulationChild(TrackWiseStub tws, String sessionId, int PRId, Field[] fields,Connection sqlConnection,Map<String, Field> parentFieldMap) throws Exception {
		int childPrId = 0;
		try {
			
			logger.info("OWS_LOG: IN  PRIVATE METHOD : createCompInvFormulationChild sessionId="+sessionId);
			final SelectionField siteNameFromGridFiled = (SelectionField) fields[1];
			final String sProjectName = PropertyReader.getProperty(Constants.COMP_INV_FORM_PROJ);
			final Selection divisionFiled = new Selection();
			String divName = siteNameFromGridFiled !=null && siteNameFromGridFiled.getSelection()!=null ?siteNameFromGridFiled.getSelection().getValue():"";
			divisionFiled.setValue(divName);
			final Selection project = new Selection();
			project.setValue(sProjectName);
			final PR childPr = tws.getEmptyPR(sessionId, divisionFiled, project);
			final Map<String, Field> childFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) childPr);
			
			/*SelectionField divisionField = (SelectionField) childFieldMap.get("Division");
			int divId = divisionField != null ?divisionField.getSelection().getId():0; 	
			SelectionField projectField = (SelectionField) childFieldMap.get("Project");
			int prjId = projectField != null ? projectField.getSelection().getId():0;*/
			
			
			final PersonField complImpactSiteOwer = (PersonField) fields[2];
			
			int compImpSiteOwnerId = complImpactSiteOwer.getPerson().getId();
			if(compImpSiteOwnerId>0) {
				Person aiCancelPerson[] = new Person[1];
				Person personObj = new Person();
				personObj.setId(compImpSiteOwnerId);
				aiCancelPerson[0] = personObj;
				MultiPersonField qaReviewer = (MultiPersonField) childFieldMap.get(PropertyReader.getProperty(Constants.QA_REVIEWER));
				if (qaReviewer == null) {
					logger.info("The multiperson field 'QA Reviewer' is not available in trackwise.");
							
				} else {
					qaReviewer.setPersons(aiCancelPerson);
				}
			}
			
			// Set CQA Reviewer from Parent PR.
			/*MultiPersonField cqaReviewerParentField = (MultiPersonField) parentFieldMap.get(PropertyReader.getProperty(Constants.CQA_REVIEWER));
		    MultiPersonField cqaReviewerChildField = (MultiPersonField)childFieldMap.get(PropertyReader.getProperty(Constants.CQA_REVIEWER));
		    Person cqaPersonAry[] =cqaReviewerParentField.getPersons();
		    if (cqaReviewerChildField == null) {
			   logger.info("The Multiperson Field 'CQA Reviewer' is not available in trackwise.");
		    } else { 
			   cqaReviewerChildField.setPersons(cqaPersonAry); 
		    }*/
			 
			
			//Set Site Name from Parent Grid Field.
		  
			SelectionField siteName = (SelectionField) childFieldMap.get(PropertyReader.getProperty(Constants.SITE_NAME));
			if (siteName == null) {
				logger.info("OWS_MSG : The Selection field 'Site Name' may not exist in TrackWise.");
			} else {
				final Selection selectionValue = new Selection();
				selectionValue.setValue(siteNameFromGridFiled !=null && siteNameFromGridFiled.getSelection()!=null ?siteNameFromGridFiled.getSelection().getValue():"");
				siteName.setSelection(selectionValue);
			}
			
			//Set Short Description from Parent Grid Field.
			final StringField shortDescFromGridFiled = (StringField) fields[0];
			StringField shortDesc = (StringField) childFieldMap.get(PropertyReader.getProperty(Constants.SHORT_DESC));
			if(shortDesc == null) {
				logger.info("OWS_MSG : The StringField 'Short Description' may not exist in TrackWise");
			}else {
				shortDesc.setValue(shortDescFromGridFiled !=null && shortDescFromGridFiled.getValue() !=null?shortDescFromGridFiled.getValue():"");
			}
			
			
			//Copy Batch Details GridFiled to Child PR from Parent PR
			final GridField parentGrid = (GridField) parentFieldMap.get(PropertyReader.getProperty(Constants.BATCH_DETAILS_GRID));
			
			//GridRow newGridRow = tws.getEmptyGridRowByPRID(sessionId, PRId,PropertyReader.getProperty(Constants.BATCH_DETAILS_GRID));
			final GridField batchDetailsGrid = (GridField) childFieldMap.get(PropertyReader.getProperty(Constants.BATCH_DETAILS_GRID));
					
			if (parentGrid != null) {
				final GridRow[] gridRows = parentGrid.getGridRows();
				if(gridRows != null && gridRows.length>0) {
					GridRow gRows[] = new GridRow[gridRows.length];
					for(int index=0;index<gridRows.length;index++) {
						final GridRow gridRow = gridRows[index];
						final Field[] gridFields = gridRow.getFields();
						
						GridRow newGridRow = tws.getEmptyGridRowByPRID(sessionId, PRId,PropertyReader.getProperty(Constants.BATCH_DETAILS_GRID));
						
						Field[] gridRowFields = newGridRow.getFields();
						
						//Batch Number
						/*final SelectionField batchNoFromGridField = (SelectionField) gridFields[0];
						final Selection batchNumberSelection = new Selection();
						batchNumberSelection.setValue(batchNoFromGridField != null && batchNoFromGridField.getSelection()!=null ? batchNoFromGridField.getSelection().getValue():"");
						
						((SelectionField) gridRowFields[0]).setSelection(batchNumberSelection);*/
						
						
						//Batch Quantity.
						final StringField batchNoFromGridField = (StringField) gridFields[0];
						((StringField) gridRowFields[0]).setValue(batchNoFromGridField !=null ?batchNoFromGridField.getValue():"");
						
						
						
						
						//Batch Quantity.
						final StringField batchQtyFromGridField = (StringField) gridFields[1];
						((StringField) gridRowFields[1]).setValue(batchQtyFromGridField !=null ?batchQtyFromGridField.getValue():"");
						
						//Manufacturing Date.
						final StringField manuFacDateFromGridField = (StringField) gridFields[2];
						((StringField) gridRowFields[2]).setValue(manuFacDateFromGridField!=null?manuFacDateFromGridField.getValue():"");
						
						//Expiry Date.
						final StringField expiryDate = (StringField) gridFields[3];
						((StringField) gridRowFields[3]).setValue(expiryDate!=null?expiryDate.getValue():"");
						
						//Dosage Form
						//final StringField dosageForm = new StringField();
						final StringField dosageFormFromGridField = (StringField) gridFields[4];
						((StringField) gridRowFields[4]).setValue(dosageFormFromGridField != null ?dosageFormFromGridField.getValue():"");
						
						//Batch Details Remark
						final StringField batchDtlRemarkFromGridField = (StringField) gridFields[5];
						((StringField) gridRowFields[5]).setValue(batchDtlRemarkFromGridField!=null?batchDtlRemarkFromGridField.getValue():"");
						
						gRows[index] = newGridRow;
					}
					
					batchDetailsGrid.setGridRows(gRows);
				}
			}
			
			//Set ParenPR ID
			final NumberField parentPRId = (NumberField)childFieldMap.get(PropertyReader.getProperty(Constants.PARENT_ID));
            if (parentPRId == null) {
                this.logger.info((Object)"The Number field '"+PropertyReader.getProperty(Constants.PARENT_ID)+"' may not exist in TrackWise.");
            }
            else {
                parentPRId.setValue(PRId);
            }
			
			// Call createPr() to create childPr.
			childPrId = tws.createPR(sessionId, childPr);
			logger.info("Comp.Inv.-Formulation Child PR created. PRID : " + childPrId);
			
		}catch (TWSException twse) {
			String twmsg = twse.getMessage();
			logger.info("PRID : "+PRId+"OWS_MSG : "+twmsg+" FAULT_MSG : "+twse.getFaultMessage()+" "+twse.getStackTrace());
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(PRId,"createCompInvFormulationChild");
			if(!isPRIDExist) {
				addFailedRecord("createCompInvFormulationChild",PRId,twmsg);
				
			}else {
				logger.info("OWS_LOG : PRID : "+PRId+" is already exist in reprocess table.");
			}
		}
		return childPrId;
	}


	@Override
	public int createCompInvAPIChild(int prId,String sessionId,TrackWiseStub tws) throws Exception {
		int newChildPrId = 0;
		try {
			logger.info("OWS_LOG : IN METHOD createCompInvAPIChild SessionId= "+sessionId+" PRDI:"+prId);
			final PR pr = Util.getPRById(tws, sessionId, prId);
			if(pr != null) {
				final Map<String, Field> fieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) pr);
				final GridField grid = (GridField) fieldMap.get(PropertyReader.getProperty(Constants.COMPIMPACTEDSITEGRID));
				if (grid != null) {
					final GridRow[] gridRows = grid.getGridRows();
					logger.info(("GridRowsLenght : " + gridRows.length));
					if(gridRows != null && gridRows.length>0) {
						List<Integer> childPRIdsList = null;
						Connection sqlConn = dbHandler.getSQLConnection();
						for (int i = 0; i < gridRows.length; ++i) {
							final GridRow gridRow = gridRows[i];
							final Field[] gridFields = gridRow.getFields();
							boolean isCreateChild = true;
							childPRIdsList = dbHandler.getChildPrId(sqlConn, prId);
							final StringField complaintDescRowValue = (StringField) gridFields[0];
							final SelectionField compImpactedSiteNameRowValue = (SelectionField) gridFields[1];
							final PersonField compImpactedSiteOwnerRowValue = (PersonField) gridFields[2];
							if(childPRIdsList != null && childPRIdsList.size()>0) {
								for(int childPrId : childPRIdsList ) {
									final PR existiningChildPr = Util.getPRById(tws, sessionId, childPrId);
									if (existiningChildPr != null) {
										final Map<String, Field> existingChildFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) existiningChildPr);
										SelectionField projectField = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.PROJECT));
										if(projectField != null && projectField.getSelection()!=null && projectField.getSelection().getValue().equals(PropertyReader.getProperty(Constants.COMP_INV_API_PROJ))) {
											SelectionField siteNameField = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.SITE_NAME));
											StringField complDescField = (StringField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.SHORT_DESC));
											MultiPersonField compImpSiteOwnerField = (MultiPersonField)existingChildFieldMap.get(PropertyReader.getProperty(Constants.QA_REVIEWER).trim());
											Person compSiteOwnerAry[] = compImpSiteOwnerField.getPersons();
											int compSiteOwnerChildPRValue=0;
											if(compSiteOwnerAry != null && compSiteOwnerAry.length>0) {
												for(int p=0;p<compSiteOwnerAry.length;p++) {
													Person personObj = compSiteOwnerAry[p];
													compSiteOwnerChildPRValue = personObj.getId();
												}
											}
											if(siteNameField != null && complDescField != null) {
												String siteName = siteNameField.getSelection() != null? siteNameField.getSelection().getValue(): "";
												if(siteName.equals(compImpactedSiteNameRowValue.getSelection().getValue()) && complaintDescRowValue.getValue().equals(complDescField.getValue()) && compImpactedSiteOwnerRowValue.getPerson().getId()==compSiteOwnerChildPRValue) {
													isCreateChild = false;
													logger.info("OWS_MSG : CHILD IS ALREADY CREATED FOR SITE NAME : "+compImpactedSiteNameRowValue+" COMP_DESC :"+complaintDescRowValue+" COMP_SITE_OWNER : "+compImpactedSiteOwnerRowValue);
												}
											}
										}
									}
								}
							}
							
							if(isCreateChild) {
								SelectionField divisionField = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.DIVISION));
								String division = divisionField != null && divisionField.getSelection() != null ? divisionField.getSelection().getValue():"";
								newChildPrId = createCompInvAPIChild(tws, sessionId, prId,gridFields,sqlConn,fieldMap);
							}
							
						}
					}else {
						logger.info("OWS_MSG : Not Grid Row found In Grid Field : "+PropertyReader.getProperty(Constants.COMPIMPACTEDSITEGRID));
					}
				}else {
					logger.info("OWS_MSG : THE GRID FIELD IS NOT AVAILABLE IN TRACKWISE.");
				}
			}else {
				logger.info("OWS_MSG : The PR NOT FOUND IN TRACKWISE FOR PRID : "+prId);
			}
		}catch(TWSException twse) {
			logger.info("PRID : "+prId+"OWS_MSG : "+twse.getMessage()+" FAULT_MSG : "+twse.getFaultMessage()+" "+twse.getStackTrace());
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(prId,"createCompInvAPIChild");
			logger.info("OWS_LOG : IS PR ID Exist in Re-process : "+isPRIDExist);
			if(!isPRIDExist) {
				addFailedRecord("createCompInvAPIChild",prId,twse.getMessage());
			}else {
				logger.info("OWS_LOG : PRID : "+prId+" is already exist in reprocess table.");
			}
		}
		return newChildPrId;
	}


	private int createCompInvAPIChild(TrackWiseStub tws, String sessionId, int prId, Field[] fields,Connection sqlConn, Map<String, Field> parentFieldMap) throws Exception {
		int childPrId = 0;
		try {
			
			final SelectionField siteNameFromGridFiled = (SelectionField) fields[1];
			final String sProjectName = PropertyReader.getProperty(Constants.COMP_INV_API_PROJ);
			final Selection divisionFiled = new Selection();
			String divName = siteNameFromGridFiled !=null && siteNameFromGridFiled.getSelection()!=null ?siteNameFromGridFiled.getSelection().getValue():"";
			divisionFiled.setValue(divName);
			final Selection project = new Selection();
			project.setValue(sProjectName);
			final PR childPr = tws.getEmptyPR(sessionId, divisionFiled, project);
			final Map<String, Field> childFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) childPr);
			
			/*SelectionField divisionField = (SelectionField) childFieldMap.get("Division");
			int divId = divisionField != null ?divisionField.getSelection().getId():0; 	
			SelectionField projectField = (SelectionField) childFieldMap.get("Project");
			int prjId = projectField != null ? projectField.getSelection().getId():0;
			*/
			
			//Set QA Reviewer from Parent PR.
			final PersonField complImpactSiteOwer = (PersonField) fields[2];
			int compImpSiteOwnerId = complImpactSiteOwer.getPerson().getId();
			if(compImpSiteOwnerId>0) {
				Person aiCancelPerson[] = new Person[1];
				Person personObj = new Person();
				personObj.setId(compImpSiteOwnerId);
				aiCancelPerson[0] = personObj;
				MultiPersonField qaReviewer = (MultiPersonField) childFieldMap.get(PropertyReader.getProperty(Constants.QA_REVIEWER));
				if (qaReviewer == null) {
					logger.info("The multiperson field 'QA Reviewer' is not available in trackwise.");
							
				} else {
					qaReviewer.setPersons(aiCancelPerson);
				}
			}
			

			//Set Site Name from Parent Grid Field.
		   
			SelectionField siteName = (SelectionField) childFieldMap.get(PropertyReader.getProperty(Constants.SITE_NAME));
			if (siteName == null) {
				logger.info("OWS_MSG : The Selection field 'Site Name' may not exist in TrackWise.");
			} else {
				final Selection selectionValue = new Selection();
				selectionValue.setValue(siteNameFromGridFiled !=null && siteNameFromGridFiled.getSelection()!=null ?siteNameFromGridFiled.getSelection().getValue():"");
				siteName.setSelection(selectionValue);
			}
			
			//Set Short Description from Parent Grid Field.
			final StringField shortDescFromGridFiled = (StringField) fields[0];
			StringField shortDesc = (StringField) childFieldMap.get(PropertyReader.getProperty(Constants.SHORT_DESC));
			if(shortDesc == null) {
				logger.info("OWS_MSG : The StringField 'Short Description' may not exist in TrackWise");
			}else {
				shortDesc.setValue(shortDescFromGridFiled !=null && shortDescFromGridFiled.getValue() !=null?shortDescFromGridFiled.getValue():"");
			}
			
			//Set ParenPR ID
			final NumberField parentPRId = (NumberField)childFieldMap.get(PropertyReader.getProperty(Constants.PARENT_ID));
            if (parentPRId == null) {
                this.logger.info((Object)"The Number field '"+PropertyReader.getProperty(Constants.PARENT_ID)+"' may not exist in TrackWise.");
            }
            else {
                parentPRId.setValue(prId);
            }
			
			
			// Call createPr() to create childPr.
			childPrId = tws.createPR(sessionId, childPr);
			logger.info("Market Complaint-API Child created. PRID : " + childPrId);
			
		}catch (TWSException twse) {
			String twmsg = twse.getMessage();
			logger.info("PRID : "+prId+"OWS_MSG : "+twmsg+" FAULT_MSG : "+twse.getFaultMessage()+" "+twse.getStackTrace());
			logger.info("OWS_LOG : Exception Occurred in Child Creation Method createCompInvAPIChild");
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(prId,"createCompInvAPIChild");
			logger.info("OWS_LOG : IS PR ID Exist in Re-process : "+isPRIDExist);
			if(!isPRIDExist) {
				addFailedRecord("createCompInvAPIChild",prId,twse.getMessage());
			}else {
				logger.info("OWS_LOG : PRID : "+prId+" is already exist in reprocess table.");
			}
			
		}
		return childPrId;	
		
	}


	@Override
	public int createCAPAFromMC(int prId,String sessionId,TrackWiseStub tws) throws Exception {
		logger.info("OWS_MSG : IN METHOD : createCAPAFromMC PRID : "+prId);
		int newChildPrId = 0;
		try {
		
			final PR parentPr = Util.getPRById(tws, sessionId, prId);
			if (parentPr != null) {
				final Map<String, Field> parentfieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) parentPr);
				
				NumberField parentPRIDField = (NumberField) parentfieldMap.get(PropertyReader.getProperty(Constants.PARENT_ID));
				int rootParentPrId = parentPRIDField.getValue();
				logger.info("OWS_LOG : rootParentPrId-->"+rootParentPrId);
				final PR pr = Util.getPRById(tws, sessionId, rootParentPrId);
				
				//Root Parent Field Map
				final Map<String, Field> fieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) pr);

				final GridField grid = (GridField) fieldMap.get(PropertyReader.getProperty(Constants.CAPA_PLAN_MC_GRID));
				//Read Parent DataField.
				final SelectionField siteNameFromParent = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.SITE_NAME));
				final SelectionField siteCodeFromParent = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.SITE_CODE));
				final SelectionField projectName = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.PROJECT));
				final MultiPersonField qaReviewerFromParent = (MultiPersonField)fieldMap.get(PropertyReader.getProperty(Constants.QA_REVIEWER));
				final MultiPersonField qaHODFromParent = (MultiPersonField)fieldMap.get(PropertyReader.getProperty(Constants.QA_HOD));
				if (grid != null) {
					final GridRow[] gridRows = grid.getGridRows();
					logger.info(("GridRowsLenght : " + gridRows.length));
					if(gridRows != null && gridRows.length>0) {
						List<Integer> childPRIdsList = null;
						Connection sqlConn = dbHandler.getSQLConnection();
						for (int i = 0; i < gridRows.length; ++i) {
							final GridRow gridRow = gridRows[i];
							final Field[] gridFields = gridRow.getFields();
							boolean isCreateChild = true;
							//int colIndex = getIndex("CAPA Already Done?",gridFields);
							
							final SelectionField isCapaPlanAlreadyDoneField = (SelectionField) gridFields[4];
							final SelectionField isCapaPlanReqField = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.CAPA_PLAN_REQ));
							String isCAPAAlreadyDone = isCapaPlanAlreadyDoneField.getSelection() != null ? isCapaPlanAlreadyDoneField.getSelection().getValue() : "";
							String isCAPAReq = isCapaPlanReqField.getSelection() != null ? isCapaPlanReqField.getSelection().getValue() : "";
							
							if(!isCAPAAlreadyDone.equals("") && !isCAPAReq.equals("") && isCAPAAlreadyDone.equals("No") && isCAPAReq.equals("Yes")) {
								//To Check Child Is Created or not For Current Row
								childPRIdsList = dbHandler.getChildPrId(sqlConn, prId);
								final SelectionField capaTypeRow = (SelectionField) gridFields[0];
								final SelectionField capaDeptRow = (SelectionField) gridFields[1];
								//final PersonField capaRespHodRow = (PersonField) gridFields[2];
								final StringField capaDescRow = (StringField) gridFields[3];
								final DateField capaTCDDateRow = (DateField) gridFields[2];
								
								if(childPRIdsList != null && childPRIdsList.size()>0) {
									for(int childPrId : childPRIdsList ) {
										final PR existiningChildPr = Util.getPRById(tws, sessionId, childPrId);
										if (existiningChildPr != null) {
											final Map<String, Field> existingChildFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) existiningChildPr);
											final SelectionField projectField = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.PROJECT));

											if(projectField !=null && projectField.getSelection()!=null && projectField.getSelection().getValue().equals(PropertyReader.getProperty(Constants.CAPA_PLAN_PROJ))) {
												final SelectionField capaTypeField = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.CAPA_TYPE));
												final StringField shortDescField = (StringField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.SHORT_DESC));
												final DateField targetDateField = (DateField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.TARGET_DATE));
												final SelectionField deptOfCAPAField = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.CAPA_DEPARTMENT));
												//final MultiPersonField respDeptHodGridField = (MultiPersonField)existingChildFieldMap.get(PropertyReader.getProperty(Constants.IMPL_DEPT_HOD));
												/*
												 * Person respDeptHodAry[] = respDeptHodGridField.getPersons(); int
												 * respHodId = 0; for(int p=0;p<respDeptHodAry.length;p++){ Person
												 * personObj = respDeptHodAry[p]; respHodId = personObj.getId(); }
												 */
												if(capaTypeField.getSelection().getValue().equals(capaTypeRow.getSelection().getValue()) && shortDescField.getValue().equals(capaDescRow.getValue()) 
														&& targetDateField.getValue().equals(capaTCDDateRow.getValue()) && capaDeptRow.getSelection().getValue().equals(deptOfCAPAField.getSelection().getValue())) {
													isCreateChild = false;
												}
											}
										}
									}
								}
								
								if(isCreateChild) {
									SelectionField divisionField = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.DIVISION));
									String division = divisionField != null && divisionField.getSelection() != null ? divisionField.getSelection().getValue():"";
									newChildPrId = createChildForCAPA(tws, sessionId, prId,sqlConn,division,siteNameFromParent,siteCodeFromParent,capaTypeRow,capaDescRow,capaTCDDateRow,projectName,capaDeptRow,qaReviewerFromParent,qaHODFromParent,"createCAPAFromMC");
									logger.info("OWS_MSG : CHILD PR CREATED FOR : "+newChildPrId);
								}
							}else {
								logger.info("OWS_LOG : The Value of Is CAPA Required should be 'YES' and The value of Is CAPA already done should be 'NO'.!!");
							}
						}
					}else {
						logger.info("OWS_MSG : NO GRID ROWS FOUND FOR GRID "+PropertyReader.getProperty(Constants.CAPA_PLAN_MC_GRID));
					}
				}else {
					logger.info("OWS_MSG : THE GRIDFIELD NOT FOUND FOR "+PropertyReader.getProperty(Constants.CAPA_PLAN_MC_GRID));
				}
			}else {
				logger.info("OWS_MSG : PR NOT FOUND FOR PR ID : "+prId);
			}
		}catch(TWSException twse) {
			String msg = twse.getMessage();
			logger.info("OWS_LOG : PRID : "+prId+"OWS_MSG :"+msg+" FAULT_MSG : "+twse.getFaultMessage());
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(prId,"createCAPAFromMC");
			logger.info("OWS_LOG : IS PR ID Exist in Re-process : "+isPRIDExist);
			if(!isPRIDExist) {
				addFailedRecord("createCAPAFromMC",prId,twse.getMessage());
				
			}else {
				logger.info("OWS_LOG : PRID : "+prId+" is already exist in reprocess table.");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return newChildPrId;
	}


	private int createChildForCAPA(TrackWiseStub tws, String sessionId, int prId,Connection sqlConn,String division,SelectionField siteNameFromParent,SelectionField siteCodeFromParent,
									SelectionField capaTypeGridField,StringField capaDescGridField,DateField capaTCDDateGridField,SelectionField projectName,SelectionField capaDeptGridField,
									MultiPersonField qaReviewerFromParent,MultiPersonField qaHODFromParent, String parentMethodName) throws Exception {
		int childPrId = 0;
		try {
			final String sProjectName = PropertyReader.getProperty(Constants.CAPA_PLAN_PROJ);
			final Selection divisionFiled = new Selection();
			divisionFiled.setValue(division.trim());
			final Selection project = new Selection();
			project.setValue(sProjectName);
			final PR childPr = tws.getEmptyPR(sessionId, divisionFiled, project);
			final Map<String, Field> childFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) childPr);
			
			SelectionField divisionField = (SelectionField) childFieldMap.get( "Division" );
			int divId = divisionField != null ? divisionField.getSelection().getId() : 0;
			SelectionField projectField = (SelectionField) childFieldMap.get( "Project" );
			int prjId = projectField != null ? projectField.getSelection().getId() : 0;
			
			
			//Set Site Name From it's Parent Value
			final SelectionField siteNameField = (SelectionField) childFieldMap.get(PropertyReader.getProperty(Constants.SITE_NAME));
			if(siteNameField == null) {
				logger.info("The Single SelectionField '"+PropertyReader.getProperty(Constants.SITE_NAME)+"' may not available in TrackWise.");
			}else {
				final Selection selectionValue = new Selection();
				selectionValue.setValue(siteNameFromParent !=null && siteNameFromParent.getSelection()!=null ?siteNameFromParent.getSelection().getValue():"");
				siteNameField.setSelection(selectionValue);
			}
			
			//Set Site Code From It's Parent Value.
			final SelectionField siteCodeField = (SelectionField) childFieldMap.get(PropertyReader.getProperty(Constants.SITE_CODE));
			if(siteCodeField == null) {
				logger.info("The Single SelectionField '"+PropertyReader.getProperty(Constants.SITE_CODE)+"' may not available in TrackWise.");
			}else {
				final Selection selectionValue = new Selection();
				selectionValue.setValue(siteCodeFromParent !=null && siteCodeFromParent.getSelection()!=null ?siteCodeFromParent.getSelection().getValue():"");
				siteCodeField.setSelection(selectionValue);
			}
			
			//Set Type of CAPA From It's Parent Grid Value.
			
			final SelectionField capaTypeField = (SelectionField) childFieldMap.get(PropertyReader.getProperty(Constants.CAPA_TYPE));
			if(capaTypeField == null) {
				logger.info("The Single SelectionField '"+PropertyReader.getProperty(Constants.CAPA_TYPE)+"' may not available in TrackWise.");
			}else {
				final Selection selectionValue = new Selection();
				selectionValue.setValue(capaTypeGridField !=null && capaTypeGridField.getSelection()!=null ?capaTypeGridField.getSelection().getValue():"");
				capaTypeField.setSelection(selectionValue);
			}
			
			//Set Short Description From It's Parent grid Value.
			
			final StringField shortDescField = (StringField) childFieldMap.get(PropertyReader.getProperty(Constants.SHORT_DESC));
			if(shortDescField == null) {
				logger.info("The StringField '"+PropertyReader.getProperty(Constants.SHORT_DESC)+"' may not available in TrackWise");
			}else {
				shortDescField.setValue(capaDescGridField !=null?capaDescGridField.getValue():"");
			}
			
			//Set Target Date From It's Parent Grid Value.
			
			final DateField targetDateField = (DateField) childFieldMap.get(PropertyReader.getProperty(Constants.TARGET_DATE));
			if(targetDateField == null) {
				logger.info("The DateField '"+PropertyReader.getProperty(Constants.TARGET_DATE)+"' may not available in trackwise.");
			}else {
				targetDateField.setValue(capaTCDDateGridField != null ? capaTCDDateGridField.getValue() : "");
			}
			
			//Set Source Of CAPA Field Form it's Parent Project.
			String sourceOfCAPA = "";
			final SelectionField sourceOfCAPAField = (SelectionField) childFieldMap.get(PropertyReader.getProperty(Constants.SOURCE_OF_CAPA));
			if(sourceOfCAPAField == null) {
				logger.info("The Single Selection Field '"+PropertyReader.getProperty(Constants.SOURCE_OF_CAPA)+"' may not available in trackwise.");
			}else {
				final Selection selectionValue = new Selection();
				if(projectName !=null && projectName.getSelection()!=null && projectName.getSelection().getValue().equals(PropertyReader.getProperty(Constants.RCI_PROJECT_NAME))) {
					sourceOfCAPA = "Investigation";
				}else {
					sourceOfCAPA = projectName !=null && projectName.getSelection()!=null ?projectName.getSelection().getValue():"";
				}
				
				selectionValue.setValue(sourceOfCAPA);
				sourceOfCAPAField.setSelection(selectionValue);
			}
			
			//Set Department of CAPA From It's Parent Grid Value.
			String deptOfCAPA = "";
			final SelectionField deptOfCAPAField = (SelectionField) childFieldMap.get(PropertyReader.getProperty(Constants.CAPA_DEPARTMENT));
			if(deptOfCAPAField == null) {
				logger.info("The Selection Value '"+PropertyReader.getProperty(Constants.CAPA_DEPARTMENT)+"' may not available in TrackWise.");
			}else {
				final Selection selectionValue = new Selection();
				deptOfCAPA = capaDeptGridField !=null && capaDeptGridField.getSelection()!=null ?capaDeptGridField.getSelection().getValue():"";
				selectionValue.setValue(deptOfCAPA);
				deptOfCAPAField.setSelection(selectionValue);
			}
			
			//Set Impl. Dept. HOD From It's Parent Grid
			List personList = dbHandler.getMultiPersonFieldForChild(sqlConn,"Impl. Dept. HOD",deptOfCAPA,divId,prjId);
			final MultiPersonField implDeptHodField = (MultiPersonField)childFieldMap.get(PropertyReader.getProperty(Constants.IMPL_DEPT_HOD));
			if(implDeptHodField == null) {
				logger.info("The MultiPersonField '"+PropertyReader.getProperty(Constants.IMPL_DEPT_HOD)+"' may not available in trackwise.");
			}else {
				if (personList != null && personList.size() > 0) {
					Person person[] = new Person[personList.size()];
					for (int i = 0; i < personList.size(); i++) {
						Person personObj = new Person();
						personObj.setId((int) personList.get(i));
						person[i] = personObj;
					}
					implDeptHodField.setPersons(person);
				} else {
					logger.info("OWS_LOG : There is no person available in trackwise based on Department : "+ deptOfCAPA + "Person Role :Impl. Dept. HOD");
				}
			}
			
			//Set QA Reviewer From It's Parent 
			
			final MultiPersonField qaReviewerChildField = (MultiPersonField)childFieldMap.get(PropertyReader.getProperty(Constants.QA_REVIEWER));
			if(qaReviewerChildField == null) {
				logger.info("The MultiPersonField '"+PropertyReader.getProperty(Constants.QA_REVIEWER)+"' may not available in trackwise.");
			}else {
				qaReviewerChildField.setPersons(qaReviewerFromParent.getPersons());
			}
			
			//Set QA HOD From It's Parent.
			
			final MultiPersonField qaHODChildField = (MultiPersonField)childFieldMap.get(PropertyReader.getProperty(Constants.QA_HOD));
			if(qaReviewerChildField == null) {
				logger.info("The MultiPersonField '"+PropertyReader.getProperty(Constants.QA_HOD)+"' may not available in trackwise.");
			}else {
				qaHODChildField.setPersons(qaHODFromParent.getPersons());
			}
			
			//Set ParenPR ID
			final NumberField parentPRId = (NumberField)childFieldMap.get(PropertyReader.getProperty(Constants.PARENT_ID));
            if (parentPRId == null) {
                this.logger.info((Object)"The Number field '"+PropertyReader.getProperty(Constants.PARENT_ID)+"' may not exist in TrackWise.");
            }
            else {
                parentPRId.setValue(prId);
            }
			
			// Call createPr() to create childPr.
			childPrId = tws.createPR(sessionId, childPr);
			logger.info("OWS_MSG : CAPA Child created. PRID : " + childPrId);
			
		}catch(TWSException twse) {
			logger.info("PRID : "+prId+"OWS_MSG : "+twse.getMessage()+" FAULT_MSG : "+twse.getFaultMessage()+" "+twse.getStackTrace());
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(prId,parentMethodName);
			logger.info("OWS_LOG : IS PR ID Exist in Re-process : "+isPRIDExist);
			if(!isPRIDExist) {
				addFailedRecord(parentMethodName,prId,twse.getMessage());
			}else {
				logger.info("OWS_LOG : PRID : "+prId+" is already exist in reprocess table.");
			}
		}
		return childPrId;
	}

	@Override
	public boolean setMetaDataForMCFormulation(int prId, String sessionId, TrackWiseStub tws) throws Exception {
		// TODO Auto-generated method stub
		boolean isUpdated = false;
		try {
			logger.info("OWS_LOG : IN Method : setMetaDataForMCFormulation PRID : "+prId);
			final PR childPr = Util.getPRById(tws, sessionId, prId);
			if(childPr != null) {
				
				//To Get Child Record Grid 
				final Map<String, Field> childFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) childPr);
				final GridField childBatchGrid = (GridField) childFieldMap.get(PropertyReader.getProperty(Constants.BATCH_DETAILS_GRID));
				
				//To get Parent Record Grid.
				final NumberField parentPRId = (NumberField)childFieldMap.get(PropertyReader.getProperty(Constants.PARENT_ID));
				int parentPrId = 0;
				PR parentPr = null;
				GridRow[] parentGridRows = null;
				if(parentPRId != null) {
					parentPrId = parentPRId.getValue();
					//parentPr = Util.getPRById(tws, sessionId, parentPrId);
					parentPr = tws.editPR(sessionId, parentPrId);
					if(parentPr != null) {
						final Map<String, Field> parentFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) parentPr);
						final GridField parentGrid = (GridField) parentFieldMap.get(PropertyReader.getProperty(Constants.BATCH_DETAILS_GRID));
						if (parentGrid != null) {
							parentGridRows = parentGrid.getGridRows();
						}
					}
				}
				
				
				if(childBatchGrid != null) {
					final GridRow[] childGridRows = childBatchGrid.getGridRows();
					logger.info(("GridRowsLenght : " + childGridRows.length));
					if(childGridRows != null && childGridRows.length>0) {
						//String colName = "Batch Number";
						for(int i=0;i<childGridRows.length;i++) {
							final GridRow childGridRow = childGridRows[i];
							final Field[] childGridFields = childGridRow.getFields();
							
							//int colIndex = getIndex(childGridFields[i].getName(),childGridFields);
							//int colIndex = getIndex(colName,childGridFields);
							
							final StringField childBatchQty = (StringField) childGridFields[1];
							
							final GridRow parentGridRow = parentGridRows[i];
							//final Field[] parentGridFields = parentGridRow.getFields();
							
							Field[] gridRowFields = parentGridRow.getFields();
							
							//Batch Quantity.
							((StringField) gridRowFields[1]).setValue(childBatchQty !=null ?childBatchQty.getValue():"");
							
						}
						
						//To check Record is locked or not.
						DBHandler dbHandler = new DBHandler();
						int waitTime = Integer.parseInt(Constants.WAIT_TIME_OUT);
						this.logger.info("OWS_LOG : Time to Wait="+waitTime);
						for(int i=1;i<4;i++) {
							boolean isPrLock = dbHandler.checkRecord(prId);
							if(isPrLock) {
								TimeUnit.SECONDS.sleep(waitTime);
								this.logger.info( "OWS_LOG : In Method setMetaDataForMCFormulation i="+i+" WEBSERVICE WAITING FOR "+waitTime+" Seconds to Release the PR Lock. PRID:"+prId );
							}else {
								this.logger.info("OWS_LOG : In Method setMetaDataForMCFormulation LOCK RELEASE. PRID : "+prId);
								break;
							}
						}
						
						//tws.updatePR(sessionId, parentPr);
						tws.updatePRRequireLock(sessionId, parentPr);
						isUpdated = true;
						logger.info("OWS_LOG: PR UPDATED SUCCESSFULLY!!!");
					}else {
						logger.info("OWS_MSG : prId:-"+prId+" THE ROWS NOT FOUND FOR GRID_FIELD"+Constants.BATCH_DETAILS_GRID);
					}
				}else {
					logger.info("THE GRID_FIELD : "+Constants.BATCH_DETAILS_GRID+" IS NOT FOUND FOR PRID : "+prId);
				}
			}else {
				logger.info("OWS_MSG : PR NOT FOUND IN TRACKWISE FOR PRID-"+prId);
			}
		}catch(TWSException twse) {
			String twMsg = twse.getMessage();
			logger.info("OWS_MSG :PRID:-"+prId+" MSG : "+twMsg+" FAULT_MSG"+twse.getFaultMessage()+" "+twse.getStackTrace());
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(prId,"setMetaDataForMCFormulation");
			logger.info("OWS_LOG : IS PR ID Exist in Re-process : "+isPRIDExist);
			if(!isPRIDExist) {
				addFailedRecord("setMetaDataForMCFormulation",prId,twse.getMessage());
			}else {
				logger.info("OWS_LOG : PRID : "+prId+" is already exist in reprocess table.");
			}
		
		}
		return isUpdated;
	}
	
	
	public static int getIndex(String colName, Field[] childGridFields){
		int index=0;
		for(int gridIndex = 0; gridIndex < childGridFields.length; gridIndex++){
			if (childGridFields[gridIndex].getName().equalsIgnoreCase(colName)){
	        	index = gridIndex;
	        	break;
	        }
	    }
	    return index;
	}

	@Override
	public int createInvActionChild(int prId, String sessionId, TrackWiseStub tws) throws Exception {
		// TODO Auto-generated method stub
		int newChildPrId = 0;
		try {
			logger.info("OWS_LOG : IN METHOD createInvActionChild PRID:"+prId);
			final PR pr = Util.getPRById(tws, sessionId, prId);
			if(pr != null) {
				final Map<String, Field> fieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) pr);
				SelectionField siteNameParentField = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.SITE_NAME));
				final MultiPersonField qaReviewerFromParent = (MultiPersonField)fieldMap.get(PropertyReader.getProperty(Constants.QA_REVIEWER));
				final GridField grid = (GridField) fieldMap.get(PropertyReader.getProperty(Constants.INV_ACTION_GRID));
				if (grid != null) {
					final GridRow[] gridRows = grid.getGridRows();
					logger.info(("GridRowsLenght : " + gridRows.length));
					if(gridRows != null && gridRows.length>0) {
						List<Integer> childPRIdsList = null;
						Connection sqlConn = dbHandler.getSQLConnection();
						for (int i = 0; i < gridRows.length; ++i) {
							final GridRow gridRow = gridRows[i];
							final Field[] gridFields = gridRow.getFields();
							
							final StringField invActionPlanDescRowValue = (StringField) gridFields[0];
							final SelectionField invActionPlanDeptRowValue = (SelectionField) gridFields[1];
							final DateField invActionPlanTCDRowValue = (DateField) gridFields[2];
							
							boolean isCreateChild = true;
							childPRIdsList = dbHandler.getChildPrId(sqlConn, prId);
							if(childPRIdsList != null && childPRIdsList.size()>0) {
								for(int childPrId : childPRIdsList) {
									final PR existiningChildPr = Util.getPRById(tws, sessionId, childPrId);
									if(existiningChildPr != null) {
										final Map<String, Field> existingChildFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) existiningChildPr);
										SelectionField projectField = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.PROJECT));
										if(projectField.getSelection().getValue().equals(PropertyReader.getProperty(Constants.INV_ACTION_PROJ))) {
											final SelectionField respDeptField = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.RESPONSIBLE_DEPT));
											final DateField targetDateField = (DateField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.TARGET_DATE));
											final StringField shortDescField = (StringField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.SHORT_DESC));
											if(respDeptField.getSelection().getValue().equals(invActionPlanDeptRowValue.getSelection().getValue())
													&& targetDateField.getValue().equals(invActionPlanTCDRowValue.getValue())
													&& shortDescField.getValue().equals(invActionPlanDescRowValue.getValue())) {
												isCreateChild = false;
											}
										}
									}
								}
							}
							
							if(isCreateChild) {
								SelectionField divisionField = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.DIVISION));
								String division = divisionField != null && divisionField.getSelection() != null ? divisionField.getSelection().getValue():"";
								newChildPrId = createInvActionChild(tws,sessionId,division,sqlConn,prId,siteNameParentField,invActionPlanDeptRowValue,invActionPlanDescRowValue,invActionPlanTCDRowValue,qaReviewerFromParent);
								logger.info("CHILD PR CREATED FOR 'Investigation Action' PRID : "+newChildPrId);
							}
						}
					}
				}else {
					logger.info("OWS_MSG : GRID_FIELD "+PropertyReader.getProperty(Constants.INV_ACTION_GRID)+"NOT FOUND FOR PR ID : "+prId);
				}
			}else {
				logger.info("OWS_MSG : prId:-"+prId+ "PR NOT FOUND IN TRACKWISE");
			}
			
		}catch (TWSException twse) {
			String twmsg = twse.getMessage();
			logger.info("PRID : "+prId+"OWS_MSG : "+twmsg+" FAULT_MSG : "+twse.getFaultMessage()+" "+twse.getStackTrace());
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(prId,"createInvActionChild");
			logger.info("OWS_LOG : IS PR ID Exist in Re-process : "+isPRIDExist);
			if(!isPRIDExist) {
				addFailedRecord("createInvActionChild",prId,twse.getMessage());
			}else {
				logger.info("OWS_LOG : PRID : "+prId+" is already exist in reprocess table.");
			}
		}
	return newChildPrId;
	}
	
	private int createInvActionChild(TrackWiseStub tws, String sessionId,String divName,Connection sqlConnection,int prId,SelectionField siteNameFromGridFiled,SelectionField invActionPlanDept,StringField invAPDesc,DateField invAPTCD,MultiPersonField qaReviewerFromParent) throws Exception {
		int childPrId = 0;
		try {
			final String sProjectName = PropertyReader.getProperty(Constants.INV_ACTION_PROJ);
			final Selection divisionFiled = new Selection();
			//String divName = siteNameFromGridFiled !=null && siteNameFromGridFiled.getSelection()!=null ?siteNameFromGridFiled.getSelection().getValue():"";
			divisionFiled.setValue(divName);
			final Selection project = new Selection();
			project.setValue(sProjectName);
			final PR childPr = tws.getEmptyPR(sessionId, divisionFiled, project);
			final Map<String, Field> childFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) childPr);
			
			SelectionField divisionField = (SelectionField) childFieldMap.get( "Division" );
			int divId = divisionField != null ? divisionField.getSelection().getId() : 0;
			SelectionField projectField = (SelectionField) childFieldMap.get( "Project" );
			int prjId = projectField != null ? projectField.getSelection().getId() : 0;
			
			String responsibleDeptName= "";
			//Set Responseible Department
			SelectionField respDeptField = (SelectionField) childFieldMap.get(PropertyReader.getProperty(Constants.RESPONSIBLE_DEPT));
			if (respDeptField == null) {
				logger.info("OWS_MSG : The Selection field 'Responsible Department' may not exist in TrackWise.");
			} else {
				final Selection selectionValue = new Selection();
				responsibleDeptName = invActionPlanDept !=null && invActionPlanDept.getSelection()!=null ?invActionPlanDept.getSelection().getValue():"";
				selectionValue.setValue(responsibleDeptName);
				respDeptField.setSelection(selectionValue);
			}
			
			//Set Short Description 
			StringField shortDescField = (StringField) childFieldMap.get(PropertyReader.getProperty(Constants.SHORT_DESC));
			if(shortDescField == null) {
				logger.info("OWS_MSG : The String field 'Short Description' may not exist in trackwise.");
			}else {
				shortDescField.setValue(invAPDesc !=null && invAPDesc.getValue() !=null?invAPDesc.getValue():"");
			}
			
			//Set Inv. Action Plan TCD.
			DateField targetDateField = (DateField)childFieldMap.get(PropertyReader.getProperty(Constants.TARGET_DATE));
			if(targetDateField == null) {
				logger.info("OWS_MSG : The DateField 'Target Date' may not exist in trackwise.");
			}else {
				targetDateField.setValue(invAPTCD !=null && invAPTCD.getValue() !=null ? invAPTCD.getValue():"");
			}
											   
			List personList = dbHandler.getMultiPersonFieldForChild(sqlConnection,"Resp. Dept. Approver",responsibleDeptName,divId,prjId);
			
			//Set Resp. Dept. Approver
			MultiPersonField respDeptApprover = (MultiPersonField) childFieldMap.get("Resp. Dept. Approver");
			if(respDeptApprover == null) {
				logger.info("The MultipersonField 'Resp. Dept. Approver' may not exist in TrackWise");
			}else {
				if (personList != null && personList.size() > 0) {
					Person person[] = new Person[personList.size()];
					for (int i = 0; i < personList.size(); i++) {
						Person personObj = new Person();
						personObj.setId((int) personList.get(i));
						person[i] = personObj;
					}
					respDeptApprover.setPersons(person);
				} else {
					logger.info("OWS_LOG : There is no person available in trackwise based on Department : "+ responsibleDeptName + "Person Role :Resp. Dept. Approver");
				}

			}
			
			//Set QA Reviewer From It's Parent 
			final MultiPersonField qaReviewerChildField = (MultiPersonField)childFieldMap.get(PropertyReader.getProperty(Constants.QA_REVIEWER));
			if(qaReviewerChildField == null) {
				logger.info("The MultiPersonField '"+PropertyReader.getProperty(Constants.QA_REVIEWER)+"' may not available in trackwise.");
			}else {
				qaReviewerChildField.setPersons(qaReviewerFromParent.getPersons());
			}
			
			
			
			// Set parentId For ChildPR
			NumberField parentPrIdField = (NumberField) childFieldMap.get("Parent ID");
			if (parentPrIdField == null) {
				logger.info("The NumberField 'Parent ID' may not exist in TrackWise.");
			} else {
				parentPrIdField.setValue(prId);
			}
			// Call createPr() to create childPr.
			childPrId = tws.createPR(sessionId, childPr);
			logger.info("CHILD PR CREATED FOR INV ACTION " + childPrId + " created.");
			
			
		}catch (TWSException twse) {
			String twmsg = twse.getMessage();
			logger.info("PRID : "+prId+"OWS_MSG : "+twmsg+" FAULT_MSG : "+twse.getFaultMessage()+" "+twse.getStackTrace());
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(prId,"createInvActionChild");
			logger.info("OWS_LOG : IS PR ID Exist in Re-process : "+isPRIDExist);
			if(!isPRIDExist) {
				addFailedRecord("createInvActionChild",prId,twse.getMessage());
			}else {
				logger.info("OWS_LOG : PRID : "+prId+" is already exist in reprocess table.");
			}
		}
		return childPrId;
	}

	@Override
	public boolean setOriginatingDept(int prId, String sessionId, TrackWiseStub tws) throws Exception {
		boolean isUpdated = false;
		try {
			logger.info("OWS_LOG : IN METHOD : setOriginatingDept PRID:"+prId);
			final PR pr = Util.getPRById(tws, sessionId, prId);
			if(pr != null) {
				final Map<String, Field> fieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) pr);
				
				//Get Department By Record Initiator.
				DBHandler dbHandler = new DBHandler();
				Connection sqlConnection = dbHandler.getSQLConnection();
				final PersonField originator = (PersonField) fieldMap.get(PropertyReader.getProperty(Constants.INITIATOR));
				int personId = originator.getPerson().getId();
				List<String> deptList = dbHandler.getDepartment(sqlConnection, personId);
				String deparmentName = "";
				if(deptList != null){
					for(String deptName : deptList) {
						deparmentName = deptName;
					}
				}
				SelectionField originatingDeptField = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.ORIGINATING_DEPT));
				if(originatingDeptField == null) {
					logger.info("The SelectionField 'Originating Department' may not exist in Trackwise.");
				}else {
					final Selection selectionValue = new Selection();
					selectionValue.setValue(deparmentName != null && !deparmentName.equals("")?deparmentName:"");
					originatingDeptField.setSelection(selectionValue);
				}
				
				//To check record is locked or not.
				int waitTime = Integer.parseInt(Constants.WAIT_TIME_OUT);
				this.logger.info("OWS_LOG : Time to Wait="+waitTime);
				for(int i=1;i<4;i++) {
					boolean isPrLock = dbHandler.checkRecord(prId);
					if(isPrLock) {
						TimeUnit.SECONDS.sleep(waitTime);
						this.logger.info( "OWS_LOG : In Method setOriginatingDept i="+i+" WEBSERVICE WAITING FOR "+waitTime+" Seconds to Release the PR Lock. PRID:"+prId );
					}else {
						this.logger.info("OWS_LOG : In Method setOriginatingDept LOCK RELEASE. PRID:"+prId);
						break;
					}
				}
				
				//tws.updatePR(sessionId, pr);
				tws.updatePRRequireLock(sessionId, pr);
				isUpdated = true;
				logger.info("ORIGINATING DEPARTMENT SAVED SUCCESSFULLY.!!");
				
			}else {
				logger.info("THE PR NOT FOUND IN SYSTEM. FOR PR ID : "+prId);
			}
		}catch (TWSException twse) {
			String twmsg = twse.getMessage();
			logger.info("PRID : "+prId+"OWS_MSG : "+twmsg+" FAULT_MSG : "+twse.getFaultMessage()+" "+twse.getStackTrace());
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(prId,"setOriginatingDept");
			logger.info("OWS_LOG : IS PR ID Exist in Re-process : "+isPRIDExist);
			if(!isPRIDExist) {
				addFailedRecord("setOriginatingDept",prId,twse.getMessage());
			}else {
				logger.info("OWS_LOG : PRID : "+prId+" is already exist in reprocess table.");
			}
		}
		
		return isUpdated;
	}

	@Override
	public int createCAPAFROMRCI(int prId, String sessionId, TrackWiseStub tws) throws Exception {
		int newChildPrId = 0;
		try {
			logger.info("OWS_LOG : IN METHOD : createCAPAFROMRCI PRID:"+prId);
			final PR pr = Util.getPRById(tws, sessionId, prId);
			if(pr != null) {
				final Map<String, Field> fieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) pr);
				
				//Read Data From Parent PR RCI
				final SelectionField siteNameFromParent = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.SITE_NAME));
				final SelectionField siteCodeFromParent = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.SITE_CODE));
				final SelectionField projectName = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.PROJECT));
				final MultiPersonField qaReviewerFromParent = (MultiPersonField)fieldMap.get(PropertyReader.getProperty(Constants.QA_REVIEWER));
				final MultiPersonField qaHODFromParent = (MultiPersonField)fieldMap.get(PropertyReader.getProperty(Constants.QA_HOD));
				final SelectionField capaReq = (SelectionField)fieldMap.get(PropertyReader.getProperty(Constants.CAPA_REQUIRED));
				
				if(capaReq.getSelection()!=null && capaReq.getSelection().getValue().equals("Yes")) {
					final GridField grid = (GridField) fieldMap.get(PropertyReader.getProperty(Constants.CAPA_PLAN_RCI_GRID));
					if (grid != null) {
						final GridRow[] gridRows = grid.getGridRows();
						logger.info(("GridRowsLenght : " + gridRows.length));
						if(gridRows != null && gridRows.length>0) {
							List<Integer> childPRIdsList = null;
							Connection sqlConn = dbHandler.getSQLConnection();
							for (int i = 0; i < gridRows.length; ++i) {
								final GridRow gridRow = gridRows[i];
								final Field[] gridFields = gridRow.getFields();
								
								//Read Data From GridField
								final SelectionField typeOfCapaRowValue = (SelectionField) gridFields[0];
								final StringField capaDescDetailsRowValue = (StringField) gridFields[1];
								final SelectionField capaDeptDetailsRowValue = (SelectionField) gridFields[2];
								final DateField capaTCDDateRowValue = (DateField) gridFields[3];
								boolean isCreateChild = true;
								childPRIdsList = dbHandler.getChildPrId(sqlConn, prId);
								if(childPRIdsList != null && childPRIdsList.size()>0) {
									for(int childPrId : childPRIdsList) {
										final PR existiningChildPr = Util.getPRById(tws, sessionId, childPrId);
										if(existiningChildPr != null) {
											final Map<String, Field> existingChildFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) existiningChildPr);
											final SelectionField projectField = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.PROJECT));
											if(projectField.getSelection() != null && projectField.getSelection().getValue().equals(PropertyReader.getProperty(Constants.CAPA_PLAN_PROJ))) {
												SelectionField typeOfCAPA = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.CAPA_TYPE));
												StringField shortDesc = (StringField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.SHORT_DESC));
												SelectionField	capaDeptRowValue = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.CAPA_DEPT));
												DateField targetDate = (DateField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.TARGET_DATE));
												if(typeOfCAPA.getSelection().getValue().equals(typeOfCapaRowValue.getSelection().getValue())
														&& capaDeptRowValue.getSelection().getValue().equals(capaDeptDetailsRowValue.getSelection().getValue())
														&& targetDate.getValue().equals(capaTCDDateRowValue.getValue())
														&& shortDesc.getValue().equals(capaDescDetailsRowValue.getValue())){
													isCreateChild = false;
													logger.info("CHILD PR ALREADY CREATED FOR DEPT : "+capaDeptRowValue.getSelection().getValue()+"DATE : "+capaTCDDateRowValue.getValue()+" DESC: "+capaDescDetailsRowValue.getValue());
												}
											
											}
										}
									}
								}else {
									logger.info("OWS_MSG : NO CHILD PR CREATED FOR THIS PRID : "+prId);
								}
							
								if(isCreateChild) {
									SelectionField divisionField = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.DIVISION));
									String division = divisionField != null && divisionField.getSelection() != null ? divisionField.getSelection().getValue():"";
									newChildPrId = createChildForCAPA(tws,sessionId,prId,sqlConn,division,siteNameFromParent,siteCodeFromParent,typeOfCapaRowValue,capaDescDetailsRowValue,capaTCDDateRowValue,projectName,capaDeptDetailsRowValue,qaReviewerFromParent,qaHODFromParent,"createCAPAFROMRCI");
									logger.info("OWS_MSG : CAPA CHILD PR CREATED FROM RCI PRID : "+newChildPrId);
								}
							
							
							}
						}else {
							logger.info("NO GRID ROWS FOUND FOR GRID "+PropertyReader.getProperty(Constants.CAPA_PLAN_RCI_GRID)+" OF PRID : "+prId);
						}
					}else {
						logger.info("GRID NOT FOUND : "+PropertyReader.getProperty(Constants.CAPA_PLAN_RCI_GRID)+" FOR PR ID:"+prId);
					}
				}
				
			}else {
				logger.info("OWS_MSG : THE PR NOT FOUND IN TRACKWISE FOR PRID : "+prId);
			}
		}catch (TWSException twse) {
			String twmsg = twse.getMessage();
			logger.info("PRID : "+prId+"OWS_MSG : "+twmsg+" FAULT_MSG : "+twse.getFaultMessage()+" "+twse.getStackTrace());
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(prId,"createCAPAFROMRCI");
			logger.info("OWS_LOG : IS PR ID Exist in Re-process : "+isPRIDExist);
			if(!isPRIDExist) {
				addFailedRecord("createCAPAFROMRCI",prId,twse.getMessage());
			}else {
				logger.info("OWS_LOG : PRID : "+prId+" is already exist in reprocess table.");
			}
		}
		return newChildPrId;
	}

	@Override
	public int createCFTChild(int prId, String sessionId, TrackWiseStub tws) throws Exception {
		// TODO Auto-generated method stub
		int newChildPrId = 0;
		try {
			
			logger.info("OWS_LOG : IN METHOD createCFTChild() PRID:"+prId);
			final PR pr = Util.getPRById(tws, sessionId, prId);
			if(pr != null) {
				final Map<String, Field> fieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) pr);
				
				final MultiPersonField qaCordinatorField = (MultiPersonField) fieldMap.get(PropertyReader.getProperty(Constants.QA_COORDINATOR));
				final PersonField initiatorParentField = (PersonField) fieldMap.get(PropertyReader.getProperty(Constants.INITIATOR));
				final MultiPersonField assigneePersonField = (MultiPersonField) fieldMap.get(PropertyReader.getProperty(Constants.ASSIGNEE_PERSON));
				final MultiPersonField qaHodField = (MultiPersonField) fieldMap.get(PropertyReader.getProperty(Constants.QA_HOD));
				final SelectionField isCFTReqField = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.CFT_REQUIRED));
				final StringField pshortDescription = (StringField) fieldMap.get(PropertyReader.getProperty(Constants.SHORT_DESC));
				
				
				if(isCFTReqField.getSelection()!=null && !isCFTReqField.getSelection().getValue().equals("") && isCFTReqField.getSelection().getValue().equals("Yes")) {
					final GridField grid = (GridField) fieldMap.get(PropertyReader.getProperty(Constants.CFT_ASSESSMENT_GRID));
					if(grid != null) {
						final GridRow[] gridRows = grid.getGridRows();
						logger.info(("GridRowsLenght : " + gridRows.length));
						if(gridRows != null && gridRows.length>0) {
							List<Integer> childPRIdsList = null;
							Connection sqlConn = dbHandler.getSQLConnection();
							for (int i = 0; i < gridRows.length; ++i) {
								final GridRow gridRow = gridRows[i];
								final Field[] gridFields = gridRow.getFields();
								final SelectionField cftDeptRowValue = (SelectionField) gridFields[0];
								
								//To Check Already CFT Is Created or not.
								boolean isCreateChild = true;
								childPRIdsList = dbHandler.getChildPrId(sqlConn, prId);
								if(childPRIdsList != null && childPRIdsList.size()>0) {
									for(int childPrId : childPRIdsList) {
										final PR existiningChildPr = Util.getPRById(tws, sessionId, childPrId);
										if(existiningChildPr != null) {
											final Map<String, Field> existingChildFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) existiningChildPr);
											SelectionField projectField = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.PROJECT));
											if(projectField.getSelection().getValue().equals(PropertyReader.getProperty(Constants.CFT_PROJECT_NAME))) {
												final SelectionField respDeptField = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.RESPONSIBLE_DEPT));
												if(respDeptField.getSelection().getValue().equals(cftDeptRowValue.getSelection().getValue())) {
													 isCreateChild = false;
													 logger.info("CFT CHILD ALREADY CREATED FOR Dept:"+cftDeptRowValue.getSelection().getValue());
												}
											}
										}
									}
								}else {
									logger.info("NO CFT CHILD CREATED YET FOR PRID : "+prId);
								}
								
								if(isCreateChild) {
									SelectionField divisionField = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.DIVISION));
									String division = divisionField != null && divisionField.getSelection() != null ? divisionField.getSelection().getValue():"";
									newChildPrId = createCFTChild(tws,sessionId,division,sqlConn,prId,cftDeptRowValue,qaCordinatorField,initiatorParentField,assigneePersonField,qaHodField,pshortDescription);
									logger.info("CHILD PR CREATED FOR 'Investigation Action' PRID : "+newChildPrId);
								}
							}
						}else {
							logger.info("NO ROW ADDED YET IN GRID : "+PropertyReader.getProperty(Constants.CFT_ASSESSMENT_GRID) +"FOR PRID : "+prId);
						}
					}else {
						logger.info("THE GRID "+PropertyReader.getProperty(Constants.CFT_ASSESSMENT_GRID)+"NOT FOUND FOR PRID : "+prId);
					}
				}else {
					logger.info("THE VALUE OF CFT Assessment Required? is NO or");
				}
				
			}else {
				logger.info("PR NOT FOUND IN TRACKWISE FOR PRID :"+prId);
			}
		}catch (TWSException twse) {
			String twmsg = twse.getMessage();
			logger.info("PRID : "+prId+"OWS_MSG : "+twmsg+" FAULT_MSG : "+twse.getFaultMessage()+" "+twse.getStackTrace());
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(prId,"createCFTChild");
			logger.info("OWS_LOG : IS PR ID Exist in Re-process : "+isPRIDExist);
			if(!isPRIDExist) {
				addFailedRecord("createCFTChild",prId,twse.getMessage());
			}else {
				logger.info("OWS_LOG : PRID : "+prId+" is already exist in reprocess table.");
			}
		}
		return newChildPrId;
	}

	private int createCFTChild(TrackWiseStub tws, String sessionId, String division, Connection sqlConn, int parentPrId,SelectionField cftDeptRowValue,MultiPersonField qaCordinatorField,PersonField initiatorParentField,MultiPersonField assigneePersonField,MultiPersonField qaHodField,StringField pshortDescription) throws Exception {
		int childPrId = 0;
		try {
			
			final String sProjectName = PropertyReader.getProperty(Constants.CFT_PROJECT_NAME);
			final Selection divisionFiled = new Selection();
			//String divName = siteNameFromGridFiled !=null && siteNameFromGridFiled.getSelection()!=null ?siteNameFromGridFiled.getSelection().getValue():"";
			divisionFiled.setValue(division);
			final Selection project = new Selection();
			project.setValue(sProjectName);
			final PR childPr = tws.getEmptyPR(sessionId, divisionFiled, project);
			final Map<String, Field> childFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) childPr);
			
			//Below Value required To Set Value Of CFT Assessment Team
			SelectionField divisionField = (SelectionField) childFieldMap.get( "Division" );
			int divId = divisionField != null ? divisionField.getSelection().getId() : 0;
			SelectionField projectField = (SelectionField) childFieldMap.get( "Project" );
			int prjId = projectField != null ? projectField.getSelection().getId() : 0;
			
			String responsibleDeptName= "";
			//Set Responseible Department
			SelectionField respDeptField = (SelectionField) childFieldMap.get(PropertyReader.getProperty(Constants.RESPONSIBLE_DEPT));
			if (respDeptField == null) {
				logger.info("OWS_MSG : The Selection field 'Responsible Department' may not exist in TrackWise.");
			} else {
				final Selection selectionValue = new Selection();
				responsibleDeptName = cftDeptRowValue !=null && cftDeptRowValue.getSelection()!=null ?cftDeptRowValue.getSelection().getValue():"";
				selectionValue.setValue(responsibleDeptName);
				respDeptField.setSelection(selectionValue);
			}
			
			//Set Short Description 
			StringField shortDescField = (StringField) childFieldMap.get(PropertyReader.getProperty(Constants.SHORT_DESC));
			if(shortDescField == null) {
				logger.info("OWS_MSG : The String field 'Short Description' may not exist in trackwise.");
			}else {
				shortDescField.setValue(pshortDescription !=null && pshortDescription.getValue() !=null?pshortDescription.getValue():"");
			}
			
			
			//Set QA Coordinator From It's Parent 
			final MultiPersonField qaCoordinatorChildField = (MultiPersonField)childFieldMap.get(PropertyReader.getProperty(Constants.QA_COORDINATOR));
			if(qaCoordinatorChildField == null) {
				logger.info("The MultiPersonField '"+PropertyReader.getProperty(Constants.QA_COORDINATOR)+"' may not available in trackwise.");
			}else {
				qaCoordinatorChildField.setPersons(qaCordinatorField.getPersons());
			}
			
			//Set Assignee Person From It's Parent 
			final MultiPersonField assigneePersonChildField = (MultiPersonField)childFieldMap.get(PropertyReader.getProperty(Constants.ASSIGNEE_PERSON));
			if(assigneePersonChildField == null) {
				logger.info("The MultiPersonField '"+PropertyReader.getProperty(Constants.ASSIGNEE_PERSON)+"' may not available in trackwise.");
			}else {
				assigneePersonChildField.setPersons(assigneePersonField.getPersons());
			}
			
			//Set QA HOD From It's Parent 
			final MultiPersonField qaHodChildField = (MultiPersonField)childFieldMap.get(PropertyReader.getProperty(Constants.QA_HOD));
			if(qaHodChildField == null) {
				logger.info("The MultiPersonField '"+PropertyReader.getProperty(Constants.QA_HOD)+"' may not available in trackwise.");
			}else {
				qaHodChildField.setPersons(qaHodField.getPersons());
			}
			
			//Set CC Initiator
			final PersonField ccInitiatorChildField = (PersonField)childFieldMap.get(PropertyReader.getProperty(Constants.CC_INITIATOR));
			if(ccInitiatorChildField == null) {
				logger.info("The PersonField may not exist in trackwise.");
			}else {
				ccInitiatorChildField.setPerson(initiatorParentField.getPerson());
			}
			
			//Set CFT Assessment Team
			List personList = dbHandler.getMultiPersonFieldForChild(sqlConn,"CFT Assessment Team",responsibleDeptName,divId,prjId);
			MultiPersonField cftTeamAssessment = (MultiPersonField) childFieldMap.get(PropertyReader.getProperty(Constants.CFT_ASSESS_TEAM));
			if(cftTeamAssessment == null) {
				logger.info("The MultipersonField 'CFT Assessment Team' may not available in Trackwise.");
			}else {
				if (personList != null && personList.size() > 0) {
					Person person[] = new Person[personList.size()];
					for (int i = 0; i < personList.size(); i++) {
						Person personObj = new Person();
						personObj.setId((int) personList.get(i));
						person[i] = personObj;
					}
					cftTeamAssessment.setPersons(person);
				} else {
					logger.info("OWS_LOG : There is no person available in trackwise based on Department : "+ responsibleDeptName + "Person Role : CFT Assessment Team");
				}
			}
			
			// Set parentId For ChildPR
			NumberField parentPrIdField = (NumberField) childFieldMap.get("Parent ID");
			if (parentPrIdField == null) {
				logger.info("The NumberField 'Parent ID' may not exist in TrackWise.");
			} else {
				parentPrIdField.setValue(parentPrId);
			}
			// Call createPr() to create childPr.
			childPrId = tws.createPR(sessionId, childPr);
			logger.info("CHILD PR CREATED FOR CFT ASSESSMENT " + childPrId + " created.");
			
		}catch (TWSException twse) {
			String twmsg = twse.getMessage();
			logger.info("PRID : "+parentPrId+"OWS_MSG : "+twmsg+" FAULT_MSG : "+twse.getFaultMessage()+" "+twse.getStackTrace());
			
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(parentPrId,"createCFTChild");
			logger.info("OWS_LOG : IS PR ID Exist in Re-process : "+isPRIDExist);
			if(!isPRIDExist) {
				addFailedRecord("createCFTChild",parentPrId,twse.getMessage());
			}else {
				logger.info("OWS_LOG : PRID : "+parentPrId+" is already exist in reprocess table.");
			}
			
			
		}
		return childPrId;
	}

	@Override
	public int createRAAssessChild(int prId, String sessionId, TrackWiseStub tws) throws Exception {
		// TODO Auto-generated method stub
		int newChildPrId = 0;
		try {
			logger.info("OWS_LOG :  IN METHOD : createRAAssessChild PRID:"+prId);
			final PR pr = Util.getPRById(tws, sessionId, prId);
			if(pr != null) {
				final Map<String, Field> fieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) pr);
				SelectionField parentProjectField = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.PROJECT));
				String parentProjName = parentProjectField.getSelection().getValue();
				SelectionField raAssessReqField = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.RA_ASSESSMENT_REQUIRED));
				//SelectionField respDeptFieldParent = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.RESPONSIBLE_DEPT));
				MultiPersonField raAssessReviewerParentField = (MultiPersonField)fieldMap.get(PropertyReader.getProperty(Constants.RA_ASSESSMENT_REVIEWER));
				
				boolean isCreateChild = true;
				if(raAssessReqField.getSelection()!= null && !raAssessReqField.getSelection().getValue().equals("") && raAssessReqField.getSelection().getValue().equals("Yes")) {
					List<Integer> childPRIdsList = null;
					Connection sqlConn = dbHandler.getSQLConnection();
					childPRIdsList = dbHandler.getChildPrId(sqlConn, prId);
					if(childPRIdsList != null && childPRIdsList.size()>0) {
						for(int childPrId : childPRIdsList) {
							final PR existiningChildPr = Util.getPRById(tws, sessionId, childPrId);
							if(existiningChildPr != null) {
								final Map<String, Field> existingChildFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) existiningChildPr);
								SelectionField projectField = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.PROJECT));
								if(projectField.getSelection().getValue().equals(PropertyReader.getProperty(Constants.RA_ASSESSMENT_PROJECT_NAME)) || projectField.getSelection().getValue().equals(PropertyReader.getProperty(Constants.TCC_RA_ASSESSMENT_PROJECT_NAME))) {
									isCreateChild = false;
								}
							}
						}
					}
					
					if(isCreateChild) {
						SelectionField divisionField = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.DIVISION));
						String division = divisionField != null && divisionField.getSelection() != null ? divisionField.getSelection().getValue():"";
						newChildPrId = createRAAssessChild(tws,sessionId,prId,division,raAssessReviewerParentField,parentProjName);
						logger.info("OWS_LOG : Child PR Created RA Assessment PRID : "+newChildPrId);
					}
				}
			}else {
				logger.info("PR NOT FOUND IN TRACKWISE FOR PR ID : "+prId);
			}
		}catch (TWSException twse) {
			String twmsg = twse.getMessage();
			logger.info("PRID : "+prId+"OWS_MSG : "+twmsg+" FAULT_MSG : "+twse.getFaultMessage()+" "+twse.getStackTrace());
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(prId,"createRAAssessChild");
			logger.info("OWS_LOG : IS PR ID Exist in Re-process : "+isPRIDExist);
			if(!isPRIDExist) {
				addFailedRecord("createRAAssessChild",prId,twse.getMessage());
			}else {
				logger.info("OWS_LOG : PRID : "+prId+" is already exist in reprocess table.");
			}
		}
		return newChildPrId;
	}

	private int createRAAssessChild(TrackWiseStub tws, String sessionId, int prId, String division,MultiPersonField raAssessReviewerParentField,String parentProjName) throws Exception {
		int childPrId = 0;	
		try {
			
			String sProjectName = null;
			if(parentProjName.equals(PropertyReader.getProperty(Constants.CC_PARENT_PROJECT))) {
				 sProjectName = PropertyReader.getProperty(Constants.RA_ASSESSMENT_PROJECT_NAME);
			}else {
				 sProjectName = PropertyReader.getProperty(Constants.TCC_RA_ASSESSMENT_PROJECT_NAME);
			}
			
			final Selection divisionFiled = new Selection();
			divisionFiled.setValue(division);
			final Selection project = new Selection();
			project.setValue(sProjectName);
			final PR childPr = tws.getEmptyPR(sessionId, divisionFiled, project);
			final Map<String, Field> childFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) childPr);
			
			//Set QA Reviewer From It's Parent 
			final MultiPersonField raAssessReviewerChildField = (MultiPersonField)childFieldMap.get(PropertyReader.getProperty(Constants.RA_ASSESSMENT_REVIEWER));
			if(raAssessReviewerChildField == null) {
				logger.info("The MultiPersonField '"+PropertyReader.getProperty(Constants.RA_ASSESSMENT_REVIEWER)+"' may not available in trackwise.");
			}else {
				raAssessReviewerChildField.setPersons(raAssessReviewerParentField.getPersons());
			}
			
			// Set parentId For ChildPR
			NumberField parentPrIdField = (NumberField) childFieldMap.get("Parent ID");
			if (parentPrIdField == null) {
				logger.info("The NumberField 'Parent ID' may not exist in TrackWise.");
			} else {
				parentPrIdField.setValue(prId);
			}
			// Call createPr() to create childPr.
			childPrId = tws.createPR(sessionId, childPr);
			logger.info("CHILD PR CREATED FOR RA Assessment" + childPrId + " created.");
			
			
		}catch (TWSException twse) {
			String twmsg = twse.getMessage();
			logger.info("PRID : "+prId+"OWS_MSG : "+twmsg+" FAULT_MSG : "+twse.getFaultMessage()+" "+twse.getStackTrace());
			
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(prId,"createRAAssessChild");
			logger.info("OWS_LOG : IS PR ID Exist in Re-process : "+isPRIDExist);
			if(!isPRIDExist) {
				addFailedRecord("createRAAssessChild",prId,twse.getMessage());
			}else {
				logger.info("OWS_LOG : PRID : "+prId+" is already exist in reprocess table.");
			}
		}
		return childPrId;
	}

	@Override
	public int createAIChild(int prId, String sessionId, TrackWiseStub tws) throws Exception {
		int newChildPrId = 0;
		try {
			logger.info("OWS_LOG : In Method : createAIChild PRID:"+prId);
			final PR pr = Util.getPRById(tws, sessionId, prId);
			if(pr != null) {
				final Map<String, Field> fieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) pr);
				final MultiPersonField qaInchargeField = (MultiPersonField) fieldMap.get(PropertyReader.getProperty(Constants.QA_INCHARGE));
				final MultiPersonField qaHodField = (MultiPersonField) fieldMap.get(PropertyReader.getProperty(Constants.QA_HOD));
				final MultiPersonField assigneePersonField = (MultiPersonField) fieldMap.get(PropertyReader.getProperty(Constants.ASSIGNEE_PERSON));
				final PersonField initiatorField = (PersonField) fieldMap.get(PropertyReader.getProperty(Constants.INITIATOR));
				
				final SelectionField projNameField = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.PROJECT));
				
				String projectName = projNameField.getSelection().getValue();
				String GRIDFIELD_NAME = null;
				if(projectName.equals("Change Control")) {
					GRIDFIELD_NAME = PropertyReader.getProperty(Constants.ACTION_PLAN_GRID);
				}else {
					GRIDFIELD_NAME = PropertyReader.getProperty(Constants.TEMP_ACTION_PLAN_GRID);
				}
				
				final GridField grid = (GridField) fieldMap.get(GRIDFIELD_NAME);
				
				if (grid != null) {
					final GridRow[] gridRows = grid.getGridRows();
					logger.info(("GridRowsLenght : " + gridRows.length));
					if(gridRows != null && gridRows.length>0) {
						List<Integer> childPRIdsList = null;
						Connection sqlConn = dbHandler.getSQLConnection();
						for (int i = 0; i < gridRows.length; ++i) {
							final GridRow gridRow = gridRows[i];
							final Field[] gridFields = gridRow.getFields();
							final SelectionField actionPlanDeptRowVal = (SelectionField) gridFields[0];
							final StringField actionDescRowVal = (StringField) gridFields[1];
							final StringField extDocNoRowVal = (StringField) gridFields[2];
							final StringField revDocNoRowVal = (StringField) gridFields[3];
							final DateField tDateActionPlanRowVal = (DateField) gridFields[4];
							boolean isCreateChild = true;
							childPRIdsList = dbHandler.getChildPrId(sqlConn, prId);
							if(childPRIdsList != null && childPRIdsList.size()>0) {
								for(int childPrId : childPRIdsList) {
									final PR existiningChildPr = Util.getPRById(tws, sessionId, childPrId);
									if(existiningChildPr != null) {
										final Map<String, Field> existingChildFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) existiningChildPr);
										SelectionField projectField = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.PROJECT));
										if(projectField.getSelection()!= null && projectField.getSelection().getValue().equals(PropertyReader.getProperty(Constants.ACTION_ITEM_PROJECT_NAME))) {
											SelectionField actionItemDept = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.ACTION_ITEM_DEPT));
											//DateField aiTargetCompDate = (DateField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.AI_TARGET_COMPLETION_DATE));
											StringField shortDesc = (StringField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.SHORT_DESC));
											StringField extDocNo = (StringField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.HID_EXT_DOC_NO));
											StringField revDocNo = (StringField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.HID_REV_DOC_NO));
											
											if(actionItemDept.getSelection().getValue().equals(actionPlanDeptRowVal.getSelection().getValue()) 
													&& shortDesc.getValue().equals(actionDescRowVal.getValue()) && extDocNoRowVal.getValue().equals(extDocNo.getValue())
													&& revDocNoRowVal.getValue().equals(revDocNo.getValue())) {
												isCreateChild = false;
												logger.info("ACTION ITEM CHILD PR CREATED FOR PR ID :"+prId);
											}
										}
									}
								}
							}
						
							if(isCreateChild) {
								SelectionField divisionField = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.DIVISION));
								String division = divisionField != null && divisionField.getSelection() != null ? divisionField.getSelection().getValue():"";
								newChildPrId = createAIChild(tws,sessionId,division,sqlConn,prId,qaInchargeField,qaHodField,assigneePersonField,initiatorField,actionPlanDeptRowVal,actionDescRowVal,tDateActionPlanRowVal,extDocNoRowVal,revDocNoRowVal,"createAIChild");
								logger.info("CHILD PR CREATED FOR 'Action Item' PRID : "+newChildPrId);
							}
						}
					}
				}else {
					logger.info("THE GRIDFIELD : "+PropertyReader.getProperty(Constants.ACTION_PLAN_GRID)+" NOT FOUND.");
				}
			}else {
				logger.info("PR NOT FOUND FOR PRID:"+prId);
			}
		}catch (TWSException twse) {
			String twmsg = twse.getMessage();
			logger.info("PRID : "+prId+"OWS_MSG : "+twmsg+" FAULT_MSG : "+twse.getFaultMessage()+" "+twse.getStackTrace());
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(prId,"createAIChild");
			logger.info("OWS_LOG : IS PR ID Exist in Re-process : "+isPRIDExist);
			if(!isPRIDExist) {
				addFailedRecord("createAIChild",prId,twse.getMessage());
			}else {
				logger.info("OWS_LOG : PRID : "+prId+" is already exist in reprocess table.");
			}
		}
		
		return newChildPrId;
	}

	private int createAIChild(TrackWiseStub tws, String sessionId, String division, Connection sqlConn, int parentPrId,
			MultiPersonField qaInchargeField, MultiPersonField qaHodField, MultiPersonField assigneePersonField,
			PersonField initiatorField, SelectionField actionPlanDeptRowVal, StringField actionDescRowVal,
			DateField tDateActionPlanRowVal,StringField extDocNoRowVal,StringField revDocNoRowVal,String parentMethodName) throws Exception {
			int childPrId = 0;
			try {
				final String sProjectName = PropertyReader.getProperty(Constants.ACTION_ITEM_PROJECT_NAME);
				final Selection divisionFiled = new Selection();
				divisionFiled.setValue(division);
				final Selection project = new Selection();
				project.setValue(sProjectName);
				final PR childPr = tws.getEmptyPR(sessionId, divisionFiled, project);
				final Map<String, Field> childFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) childPr);
				
				//Below Value required To Set Value Of CFT Assessment Team
				SelectionField divisionField = (SelectionField) childFieldMap.get( "Division" );
				int divId = divisionField != null ? divisionField.getSelection().getId() : 0;
				SelectionField projectField = (SelectionField) childFieldMap.get( "Project" );
				int prjId = projectField != null ? projectField.getSelection().getId() : 0;
				
				String actionPlanDept = "";
				//Set Action Item Department.
				SelectionField actionItemDeptField = (SelectionField) childFieldMap.get(PropertyReader.getProperty(Constants.ACTION_ITEM_DEPT));
				if(actionItemDeptField == null) {
					logger.info("The SelectionField '"+PropertyReader.getProperty(Constants.ACTION_ITEM_DEPT)+"' may not exist in trackwise.");
				}else {
					final Selection selectionValue = new Selection();
					actionPlanDept = actionPlanDeptRowVal !=null && actionPlanDeptRowVal.getSelection()!=null ?actionPlanDeptRowVal.getSelection().getValue():"";
					selectionValue.setValue(actionPlanDept);
					actionItemDeptField.setSelection(selectionValue);
				}
				
				//Set Short Description 
				StringField shortDescField = (StringField) childFieldMap.get(PropertyReader.getProperty(Constants.SHORT_DESC));
				if(shortDescField == null) {
					logger.info("OWS_MSG : The String field 'Short Description' may not exist in trackwise.");
				}else {
					shortDescField.setValue(actionDescRowVal !=null && actionDescRowVal.getValue() !=null?actionDescRowVal.getValue():"");
				}
				
				//Set Hid-Existing doc. No.
				StringField hidExtDocNoField = (StringField) childFieldMap.get(PropertyReader.getProperty(Constants.HID_EXT_DOC_NO));
				if(hidExtDocNoField == null) {
					logger.info("OWS_MSG : The String field 'Hid-Existing doc. No.' may not exist in trackwise.");
				}else {
					hidExtDocNoField.setValue(extDocNoRowVal !=null && extDocNoRowVal.getValue() !=null?extDocNoRowVal.getValue():"");
				}
				
				//Set Hid-Revi. /New Doc No.
				StringField hidRevDocNoField = (StringField) childFieldMap.get(PropertyReader.getProperty(Constants.HID_REV_DOC_NO));
				if(hidRevDocNoField == null) {
					logger.info("OWS_MSG : The String field 'Hid-Revi. /New Doc No' may not exist in trackwise.");
				}else {
					hidRevDocNoField.setValue(revDocNoRowVal !=null && revDocNoRowVal.getValue() !=null?revDocNoRowVal.getValue():"");
				}
				
				
				//Set AI Target Completion Date.
				DateField aiTargetCompDate = (DateField) childFieldMap.get(PropertyReader.getProperty(Constants.AI_TARGET_COMPLETION_DATE));
				if(aiTargetCompDate == null) {
					logger.info("The DateField '"+PropertyReader.getProperty(Constants.AI_TARGET_COMPLETION_DATE)+"' may not exist in trackwise.");
				}else {
					aiTargetCompDate.setValue(tDateActionPlanRowVal.getValue());
				}
				
				//Set QA Incharge From It's Parent 
				final MultiPersonField qaInchargeChildField = (MultiPersonField)childFieldMap.get(PropertyReader.getProperty(Constants.QA_INCHARGE));
				if(qaInchargeChildField == null) {
					logger.info("The MultiPerson Field '"+PropertyReader.getProperty(Constants.QA_INCHARGE)+"' may not exist in trackwise.");
				}else {
					qaInchargeChildField.setPersons(qaInchargeField.getPersons());
				}
				
				//Set Assignee Person From It's Parent 
				final MultiPersonField assigneePersonChildField = (MultiPersonField)childFieldMap.get(PropertyReader.getProperty(Constants.ASSIGNEE_PERSON));
				if(assigneePersonChildField == null) {
					logger.info("The MultiPersonField '"+PropertyReader.getProperty(Constants.ASSIGNEE_PERSON)+"' may not available in trackwise.");
				}else {
					assigneePersonChildField.setPersons(assigneePersonField.getPersons());
				}
				
				//Set QA HOD From It's Parent 
				final MultiPersonField qaHodChildField = (MultiPersonField)childFieldMap.get(PropertyReader.getProperty(Constants.QA_HOD));
				if(qaHodChildField == null) {
					logger.info("The MultiPersonField '"+PropertyReader.getProperty(Constants.QA_HOD)+"' may not available in trackwise.");
				}else {
					qaHodChildField.setPersons(qaHodField.getPersons());
				}
				
				//Set CC Initiator
				final PersonField ccInitiatorChildField = (PersonField)childFieldMap.get(PropertyReader.getProperty(Constants.CC_INITIATOR));
				if(ccInitiatorChildField == null) {
					logger.info("The PersonField may not exist in trackwise.");
				}else {
					ccInitiatorChildField.setPerson(initiatorField.getPerson());
				}
				
				//Set Action Implementor
				List personList = dbHandler.getMultiPersonFieldForChild(sqlConn,"Action Implementor",actionPlanDept,divId,prjId);
				MultiPersonField actionItemImple = (MultiPersonField) childFieldMap.get(PropertyReader.getProperty(Constants.ACTION_IMPLEMENTER));
				if(actionItemImple == null) {
					logger.info("The MultipersonField '"+PropertyReader.getProperty(Constants.ACTION_IMPLEMENTER)+"' may not exist in trackwise.");
				}else {
					if (personList != null && personList.size() > 0) {
						Person person[] = new Person[personList.size()];
						for (int i = 0; i < personList.size(); i++) {
							Person personObj = new Person();
							personObj.setId((int) personList.get(i));
							person[i] = personObj;
						}
						actionItemImple.setPersons(person);
					} else {
						logger.info("OWS_LOG : There is no person available in trackwise based on Department : "+ actionPlanDept + "Person Role :#");
					}
				}
				
				// Set parentId For ChildPR
				NumberField parentPrIdField = (NumberField) childFieldMap.get("Parent ID");
				if (parentPrIdField == null) {
					logger.info("The NumberField 'Parent ID' may not exist in TrackWise.");
				} else {
					parentPrIdField.setValue(parentPrId);
				}
				// Call createPr() to create childPr.
				childPrId = tws.createPR(sessionId, childPr);
				logger.info("CHILD PR CREATED FOR Action Item " + childPrId + " created.");
			
			}catch (TWSException twse) {
				String twmsg = twse.getMessage();
				logger.info("PRID : "+parentPrId+"OWS_MSG : "+twmsg+" FAULT_MSG : "+twse.getFaultMessage()+" "+twse.getStackTrace());
				
				boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(parentPrId,parentMethodName);
				logger.info("OWS_LOG : IS PR ID Exist in Re-process : "+isPRIDExist);
				if(!isPRIDExist) {
					addFailedRecord(parentMethodName,parentPrId,twse.getMessage());
				}else {
					logger.info("OWS_LOG : PRID : "+parentPrId+" is already exist in reprocess table.");
				}
				
			}
			return childPrId;
	}

	@Override
	public int createAdditionalAIChild(int prId, String sessionId, TrackWiseStub tws) throws Exception {
		int newChildPrId = 0;
		try {
			logger.info("OWS_LOG : In Method createAdditionalAIChild PRID: "+prId);
			final PR pr = Util.getPRById(tws, sessionId, prId);
			if(pr != null) {
				final Map<String, Field> fieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) pr);
				final MultiPersonField qaInchargeField = (MultiPersonField) fieldMap.get(PropertyReader.getProperty(Constants.QA_INCHARGE));
				final MultiPersonField qaHodField = (MultiPersonField) fieldMap.get(PropertyReader.getProperty(Constants.QA_HOD));
				final MultiPersonField assigneePersonField = (MultiPersonField) fieldMap.get(PropertyReader.getProperty(Constants.ASSIGNEE_PERSON));
				final PersonField initiatorField = (PersonField) fieldMap.get(PropertyReader.getProperty(Constants.INITIATOR));
				
				final GridField grid = (GridField) fieldMap.get(PropertyReader.getProperty(Constants.ADDITIONAL_ACTION_PLAN_GRID));
				if (grid != null) {
					final GridRow[] gridRows = grid.getGridRows();
					logger.info(("GridRowsLenght : " + gridRows.length));
					if(gridRows != null && gridRows.length>0) {
						List<Integer> childPRIdsList = null;
						Connection sqlConn = dbHandler.getSQLConnection();
						for (int i = 0; i < gridRows.length; ++i) {
							final GridRow gridRow = gridRows[i];
							final Field[] gridFields = gridRow.getFields();
							final SelectionField addActionPlanDeptRowVal = (SelectionField) gridFields[0];
							final StringField addActionDescRowVal = (StringField) gridFields[1];
							final StringField extDocNoRowVal = (StringField) gridFields[2];
							final StringField revDocNoRowVal = (StringField) gridFields[3];
							final DateField addTDateActionPlanRowVal = (DateField) gridFields[4];
							boolean isCreateChild = true;
							childPRIdsList = dbHandler.getChildPrId(sqlConn, prId);
							if(childPRIdsList != null && childPRIdsList.size()>0) {
								for(int childPrId : childPRIdsList) {
									final PR existiningChildPr = Util.getPRById(tws, sessionId, childPrId);
									if(existiningChildPr != null) {
										final Map<String, Field> existingChildFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) existiningChildPr);
										SelectionField projectField = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.PROJECT));
										if(projectField.getSelection()!= null && projectField.getSelection().getValue().equals(PropertyReader.getProperty(Constants.ACTION_ITEM_PROJECT_NAME))) {
											SelectionField actionPlanDept = (SelectionField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.ACTION_ITEM_DEPT));
											//DateField aiTargetCompDate = (DateField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.AI_TARGET_COMPLETION_DATE));
											StringField shortDesc = (StringField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.SHORT_DESC));
											StringField extDocNo = (StringField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.HID_EXT_DOC_NO));
											StringField revDocNo = (StringField) existingChildFieldMap.get(PropertyReader.getProperty(Constants.HID_REV_DOC_NO));
											
											if(actionPlanDept.getSelection().getValue().equals(addActionPlanDeptRowVal.getSelection().getValue()) 
													&& shortDesc.getValue().equals(addActionDescRowVal.getValue()) && extDocNo.getValue().equals(extDocNoRowVal.getValue())
													&& revDocNo.getValue().equals(revDocNoRowVal.getValue())) {
												isCreateChild = false;
												logger.info("ACTION ITEM CHILD PR CREATED FOR PR ID :"+prId);
											}
										}
									}
								}
							}else {
								logger.info("No Child PR created Yet for PRID : "+prId);
							}
							
							if(isCreateChild) {
								SelectionField divisionField = (SelectionField) fieldMap.get(PropertyReader.getProperty(Constants.DIVISION));
								String division = divisionField != null && divisionField.getSelection() != null ? divisionField.getSelection().getValue():"";
								newChildPrId = createAIChild(tws,sessionId,division,sqlConn,prId,qaInchargeField,qaHodField,assigneePersonField,initiatorField,addActionPlanDeptRowVal,addActionDescRowVal,addTDateActionPlanRowVal,extDocNoRowVal,revDocNoRowVal,"createAdditionalAIChild");
								logger.info("CHILD PR CREATED FOR 'Investigation Action' PRID : "+newChildPrId);
							}
							
							
						}
					}
				}else {
					logger.info("The GirdField '"+PropertyReader.getProperty(Constants.ADDITIONAL_ACTION_PLAN_GRID)+"' Not Found for PR ID : "+prId);
				}
				
				
			}else {
				logger.info("The PR Not found in trackwise for prid:"+prId);
			}
		}catch (TWSException twse) {
			String twmsg = twse.getMessage();
			logger.info("PRID : "+prId+"OWS_MSG : "+twmsg+" FAULT_MSG : "+twse.getFaultMessage()+" "+twse.getStackTrace());
			
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(prId,"createAdditionalAIChild");
			logger.info("OWS_LOG : IS PR ID Exist in Re-process : "+isPRIDExist);
			if(!isPRIDExist) {
				addFailedRecord("createAdditionalAIChild",prId,twse.getMessage());
			}else {
				logger.info("OWS_LOG : PRID : "+prId+" is already exist in reprocess table.");
			}
		}
		return newChildPrId;
	}

	@Override
	public boolean copyChildGridToParent(int prId, String sessionId, TrackWiseStub tws) throws Exception {
		int parentPrId = 0;
		boolean isUpdated = false;
		try {
			logger.info("OWS_LOG : In Method : copyChildGridToParent PRID:"+prId);
			//Department Map for GridFieldName.
			Map<String, String>gridNameMap = new HashMap<String, String>();
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_1),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_1));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_2),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_2));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_3),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_3));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_4),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_4));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_5),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_5));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_6),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_6));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_7),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_7));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_8),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_8));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_9),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_9));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_10),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_10));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_11),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_11));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_12),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_12));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_13),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_13));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_14),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_14));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_15),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_15));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_16),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_16));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_17),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_17));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_18),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_18));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_19),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_19));
			gridNameMap.put(PropertyReader.getProperty(Constants.DEPARTMENT_20),PropertyReader.getProperty(Constants.ACTION_ITEM_GRID_20));	
			
			final PR childPr = Util.getPRById(tws, sessionId, prId);
			if(childPr != null) {
				final Map<String, Field> childFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) childPr);
				final SelectionField respDeptField = (SelectionField) childFieldMap.get(PropertyReader.getProperty(Constants.RESPONSIBLE_DEPT));
				SelectionField projectField = (SelectionField) childFieldMap.get(PropertyReader.getProperty(Constants.PROJECT));
				final NumberField parentPrIdField = (NumberField) childFieldMap.get(PropertyReader.getProperty(Constants.PARENT_ID));
				parentPrId = parentPrIdField.getValue();
				//final PR parentPr = Util.getPRById(tws, sessionId,parentPrId);
				PR parentPr = tws.editPR(sessionId, parentPrId);
				if(parentPr != null) {
					Map<String, Field> parentFieldMap = (Map<String, Field>) Util.toFieldMap((ComplexType) parentPr);
					
					String GRIDFIELD_NAME = null;
					
					SelectionField parentProjectField = (SelectionField) parentFieldMap.get(PropertyReader.getProperty(Constants.PROJECT));
					String parentProjName = parentProjectField.getSelection().getValue();
					if(parentProjName.equals("Change Control")) {
						GRIDFIELD_NAME = PropertyReader.getProperty(Constants.ACTION_PLAN_GRID);
					}else {
						GRIDFIELD_NAME = PropertyReader.getProperty(Constants.TEMP_ACTION_PLAN_GRID);
					}
					
					GridField parentGrid = (GridField) parentFieldMap.get(GRIDFIELD_NAME);
					if(parentGrid != null) {
						GridRow oldRows[] = parentGrid.getGridRows();
						String gridFieldName = "";
						if(projectField.getSelection().getValue().equals(PropertyReader.getProperty(Constants.RA_ASSESSMENT_PROJECT_NAME.trim()))) {
							gridFieldName = "Action Plan (RA)";
						}else if(projectField.getSelection().getValue().equals(PropertyReader.getProperty(Constants.CFT_PROJECT_NAME))) {
							String respDeptname = respDeptField.getSelection().getValue();
							gridFieldName = gridNameMap.get(respDeptname);
						}
						
						final GridField childGrid = gridFieldName != null ? (GridField) childFieldMap.get(gridFieldName.trim()):null;
						if(childGrid != null) {
							GridRow[] childGridRows = childGrid.getGridRows();
							
							List<GridRow> uniqueChildRows=checkChildDuplicate(childGridRows);
							
							if(uniqueChildRows != null && uniqueChildRows.size()>0) {
								List duplicateRowList = null;
								String childRespDept = respDeptField.getSelection().getValue();
								if(oldRows != null && oldRows.length>0) {
									duplicateRowList = checkDuplicate(oldRows,childGridRows,childRespDept); 
								}
								int childLength = uniqueChildRows.size();
								if(duplicateRowList != null && duplicateRowList.size()>0) {
									childLength = childGridRows.length-duplicateRowList.size();
								}
								int oldLength = oldRows!= null ? oldRows.length:0;
								GridRow gRows[] = new GridRow[childLength+oldLength];
								int i = 0;
								//To Add Old Row's
								if(oldLength>0) {
									for(int index=0;index<oldRows.length;index++) {
										gRows[index] = oldRows[index];
										i++;
									}
								}
								
								for(int index=0;index<uniqueChildRows.size();index++) {
									final GridRow gridRow = uniqueChildRows.get(index);
									final Field[] gridFields = gridRow.getFields();
									GridRow newGridRow = tws.getEmptyGridRowByPRID(sessionId, prId,PropertyReader.getProperty(Constants.ACTION_PLAN_GRID));
									Field[] gridRowFields = newGridRow.getFields();
									final StringField actionDescGridField = (StringField) gridFields[0];
									final StringField existingDocNoGridField = (StringField) gridFields[1];
									final StringField reviDocNoGridField = (StringField) gridFields[2];
									final DateField targetDateField = (DateField) gridFields[3];
									//boolean isRowExist = isRowExist(oldRows,actionDescGridField,existingDocNoGridField,reviDocNoGridField,targetDateField,childRespDept);
									if(duplicateRowList!= null && duplicateRowList.size()>0 && duplicateRowList.contains(index)) {
										continue;
									}
									
									final Selection actionDeptFieldSelection = new Selection();
									actionDeptFieldSelection.setValue(respDeptField != null && respDeptField.getSelection()!=null ? respDeptField.getSelection().getValue():"");
									((SelectionField) gridRowFields[0]).setSelection(actionDeptFieldSelection);
									
									//Action Description
									((StringField) gridRowFields[1]).setValue(actionDescGridField !=null ?actionDescGridField.getValue():"");
									//Existing Doc No
									((StringField) gridRowFields[2]).setValue(existingDocNoGridField !=null ?existingDocNoGridField.getValue():"");
									//Revi.New Doc No.
									((StringField) gridRowFields[3]).setValue(reviDocNoGridField !=null ?reviDocNoGridField.getValue():"");
									//Target Date.
									((DateField) gridRowFields[4]).setValue(targetDateField !=null ?targetDateField.getValue():"");
									gRows[i] = newGridRow;
									i++;
								}
								
								parentGrid.setGridRows(gRows);
								//tws.updatePR(sessionId, parentPr);
								//TO check the record is locked or not.
								
								int waitTime = Integer.parseInt(Constants.WAIT_TIME_OUT);
								this.logger.info("OWS_LOG : Time to Wait="+waitTime);
								for(int j=1;j<4;j++) {
									boolean isPrLock = dbHandler.checkRecord(prId);
									if(isPrLock) {
										TimeUnit.SECONDS.sleep(waitTime);
										this.logger.info( "OWS_LOG : In Method copyChildGridToParent j="+j+" WEBSERVICE WAITING FOR "+waitTime+" Seconds to Release the PR Lock. PRID:"+prId );
									}else {
										this.logger.info("OWS_LOG : In Method copyChildGridToParent LOCK RELEASE. PRID:"+prId);
										break;
									}
								}
								
								tws.updatePRRequireLock(sessionId, parentPr);
								logger.info("OWS_LOG : PRID : "+parentPrId+"Record Updated Successfully.!!");
								isUpdated = true;
							}
						}
					}
				}
			}
		}catch (TWSException twse) {
			String twmsg = twse.getMessage();
			logger.info("PRID : "+prId+"OWS_MSG : "+twmsg+" FAULT_MSG : "+twse.getFaultMessage()+" "+twse.getStackTrace());
			boolean isPRIDExist = RecordReprocessImple.getInstance().findByPRIDAndMethodName(prId,"copyChildGridToParent");
			logger.info("OWS_LOG : IS PR ID Exist in Re-process : "+isPRIDExist);
			if(!isPRIDExist) {
				addFailedRecord("copyChildGridToParent",prId,twse.getMessage());
			}else {
				logger.info("OWS_LOG : PRID : "+prId+" is already exist in reprocess table.");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return isUpdated;
	}
	
	/*private boolean isRowExist(GridRow[] oldRows, StringField cactionDescGridField, StringField cexistingDocNoGridField,
			StringField creviDocNoGridField, DateField ctargetDateField,String childRespDept) {
		boolean isExist = true;
		try {
			if(oldRows != null && oldRows.length>0) {
				for(int index=0;index<oldRows.length;index++) {
					final GridRow gridRow = oldRows[index];
					final Field[] gridFields = gridRow.getFields();
					final StringField pactionDescGridField = (StringField) gridFields[1];
					final StringField pexistingDocNoGridField = (StringField) gridFields[2];
					final StringField previDocNoGridField = (StringField) gridFields[3];
					final DateField ptargetDateField = (DateField) gridFields[4];
					if(pactionDescGridField.getValue().equals(cactionDescGridField.getValue()) && pexistingDocNoGridField.getValue().equals(cexistingDocNoGridField.getValue()) 
							&& previDocNoGridField.getValue().equals(creviDocNoGridField.getValue()) && ptargetDateField.getValue().equals(ctargetDateField.getValue())) {
						isExist = false;
						break;
					}
					
				}
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		return isExist;
	}*/
	
	private List<Integer> checkDuplicate(GridRow[] oldRows,GridRow[] childRows,String childRespDept) {
		
		List<Integer> childDupl = new ArrayList<Integer>();
		
		for(int i=0;i<oldRows.length;i++) {
			final GridRow oldgridRow = oldRows[i];
			final Field[] oldgridFields = oldgridRow.getFields();
			final SelectionField parentDeptField = (SelectionField) oldgridFields[0];
			final StringField pactionDescGridField = (StringField) oldgridFields[1];
			final StringField pexistingDocNoGridField = (StringField) oldgridFields[2];
			final StringField previDocNoGridField = (StringField) oldgridFields[3];
			final DateField ptargetDateField = (DateField) oldgridFields[4];
			
			for(int childRow=0;childRow<childRows.length;childRow++) {
				final GridRow childgridRow = childRows[childRow];
				final Field[] childgridFields = childgridRow.getFields();
				final StringField childDescGridField = (StringField) childgridFields[0];
				final StringField childExtDocNoGridField = (StringField) childgridFields[1];
				final StringField childRevDocNoGridField = (StringField) childgridFields[2];
				final DateField childTDateGridField = (DateField) childgridFields[3];
				if(pactionDescGridField.getValue().equals(childDescGridField.getValue()) && pexistingDocNoGridField.getValue().equals(childExtDocNoGridField.getValue()) 
						&& previDocNoGridField.getValue().equals(childRevDocNoGridField.getValue()) && ptargetDateField.getValue().equals(childTDateGridField.getValue())
						&& parentDeptField.getSelection().getValue().equals(childRespDept)) {
					
					childDupl.add(childRow);
				}	
			}
		}
		return childDupl;
	}

	private List<GridRow> checkChildDuplicate(GridRow[] childRows) {
		List<GridRow> uniqueChildGridRow = new ArrayList<GridRow>();
		
		if(childRows !=null && childRows.length>0) {
			for(int childRow=0;childRow<childRows.length;childRow++) {
				final GridRow childgridRow = childRows[childRow];
				final Field[] childgridFields = childgridRow.getFields();
				final StringField childDescGridField = (StringField) childgridFields[0];
				final StringField childExtDocNoGridField = (StringField) childgridFields[1];
				final StringField childRevDocNoGridField = (StringField) childgridFields[2];
				final DateField childTDateGridField = (DateField) childgridFields[3];
				boolean isExist = false;
				if(childRow==0) {
					uniqueChildGridRow.add(childgridRow);
				}
				
				for(int i=0;i<uniqueChildGridRow.size();i++) {
					final GridRow uniqueChildRow = uniqueChildGridRow.get(i);
					final Field[] childgridFieldsUnique = uniqueChildRow.getFields();
					final StringField childDescGridFieldNext = (StringField) childgridFieldsUnique[0];
					final StringField childExtDocNoGridFieldNext = (StringField) childgridFieldsUnique[1];
					final StringField childRevDocNoGridFieldNext = (StringField) childgridFieldsUnique[2];
					final DateField childTDateGridFieldNext = (DateField) childgridFieldsUnique[3];
					if(childDescGridFieldNext.getValue().equals(childDescGridField.getValue()) && childExtDocNoGridFieldNext.getValue().equals(childExtDocNoGridField.getValue())
							&& childRevDocNoGridFieldNext.getValue().equals(childRevDocNoGridField.getValue()) && childTDateGridFieldNext.getValue().equals(childTDateGridField.getValue())) {
						isExist = true;
						break;
					}
				}
				
				if(!isExist) {
					uniqueChildGridRow.add(childgridRow);
				}
				
			}
		}
		return uniqueChildGridRow;
	}
	
	public void addFailedRecord(String methodName, int prId,String emsg) throws Exception{
		logger.info("OWS_LOG : Enter In method addFailedRecord");
		logger.info("OWS_LOG : The PRID : "+prId+" added for re-process.");
		RecordReprocessEntity recordEntity = new RecordReprocessEntity();
		recordEntity.setPrId(prId);
		recordEntity.setMethodName(methodName);
		recordEntity.setIsProcessed(0);
		recordEntity.setExceptionMsg(emsg);
		RecordReprocessImple.getInstance().addRecord(recordEntity);
		logger.info("OWS_LOG : Exit from method addFailedRecord");
	}
	
}
