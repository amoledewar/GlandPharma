package net.impact.tw.imple;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

import net.impact.tw.constants.Constants;
import net.impact.tw.dao.RecordReprocessDAO;
import net.impact.tw.dto.RecordReprocessEntity;
import net.impact.tw.helper.DBHandler;
import net.impact.tw.helper.PropertyReader;

public class RecordReprocessImple implements RecordReprocessDAO {
	
	private static RecordReprocessImple instance = null;
	Logger logger;
	DBHandler db = new DBHandler();
	private RecordReprocessImple() {
		this.logger = Logger.getLogger((Class) RecordReprocessImple.class);
	}
	
	public static RecordReprocessImple getInstance() {
		if(instance == null) {
			instance = new RecordReprocessImple();
		}
		return instance;
	}

	@Override
	public void addRecord(RecordReprocessEntity recordEntity) throws Exception {
		// TODO Auto-generated method stub
		
		logger.info("OWS_LOG : Enter In method addRecord");
		try {
			Connection con = db.getSQLConnection();
			PreparedStatement pst = con.prepareStatement(PropertyReader.getProperty(Constants.ADD_FAILED_RECORD));
			pst.setInt(1, recordEntity.getPrId());
			pst.setString(2, recordEntity.getMethodName());
			pst.setInt(3, 0);
			pst.setString(4, recordEntity.getExceptionMsg());
			pst.executeUpdate();
		}catch(Exception e) {
			logger.info("OWS_LOG : Exception Occurred in Method : RecordReprocessEntity MSG:"+e.getMessage());
		}
	}
	
	
	@Override
	public RecordReprocessEntity findById(int id) throws Exception {
		logger.info("OWS_LOG : Enter In method findById");
		RecordReprocessEntity recordEntity = new RecordReprocessEntity();
		try {
			Connection con = db.getSQLConnection();
			PreparedStatement pst = con.prepareStatement(PropertyReader.getProperty(Constants.FIND_BY_ID));
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				recordEntity.setPrId(rs.getInt("PRID"));
				recordEntity.setMethodName(rs.getString("METHOD_NAME"));
				recordEntity.setIsProcessed(rs.getInt("IS_PROCESSED"));
				recordEntity.setDate(rs.getString("DATE_CREATED"));
				recordEntity.setExceptionMsg(rs.getString("EXCEPTION_MSG"));
			}
		}catch(Exception e) {
			logger.info("OWS_LOG : Exception Occurred in Method : RecordReprocessEntity msg="+e.getMessage());
		}
		
		return recordEntity;
	}

	@Override
	public List<RecordReprocessEntity> searchPendingRecordToProcess() throws Exception {
		// TODO Auto-generated method stub
		logger.info("OWS_LOG : Enter In method searchPendingRecordToProcess");
		List<RecordReprocessEntity> recordList = new ArrayList<RecordReprocessEntity>();
		try {
			Connection con = db.getSQLConnection();
			System.out.println("--->"+PropertyReader.getProperty(Constants.FIND_PENDING_RECORDS));
			PreparedStatement pst = con.prepareStatement(PropertyReader.getProperty(Constants.FIND_PENDING_RECORDS));
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				RecordReprocessEntity recordEntity = new RecordReprocessEntity();
				recordEntity.setPrId(rs.getInt("PRID"));
				recordEntity.setMethodName(rs.getString("METHOD_NAME"));
				recordEntity.setIsProcessed(rs.getInt("IS_PROCESSED"));
				recordEntity.setExceptionMsg(rs.getString("EXCEPTION_MSG"));
				recordList.add(recordEntity);
			}
		}catch(Exception e) {
			logger.info("OWS_LOG : Exception Occurred in Method : searchPendingRecordToProcess msg="+e.getMessage());
		}
		
		return recordList;
	}

	@Override
	public void updateProcessedRecord(RecordReprocessEntity recordEntity) throws Exception {
		// TODO Auto-generated method stub
		logger.info("OWS_LOG : Enter In method updateProcessedRecord");
		try {
			Connection con = db.getSQLConnection();
			PreparedStatement pst = con.prepareStatement(PropertyReader.getProperty(Constants.UPDATE_PROCESSED_RECORD));
			pst.setInt(1, recordEntity.getPrId());
			pst.setString(2, recordEntity.getMethodName());
			pst.setInt(3, 1);
			pst.setString(4, recordEntity.getExceptionMsg());
			pst.setInt(5, recordEntity.getId());
			pst.executeUpdate();
			
		}catch(Exception e) {
			logger.info("OWS_LOG : Exception Occurred in Method : updateProcessedRecord msg="+e.getMessage());
		}
		
		
	}

	@Override
	public boolean findByPRIDAndMethodName(int prId,String methodName) throws Exception {
		boolean isExist = false;
		logger.info("OWS_LOG : Enter In method isPRExist");
		try {
			Connection con = db.getSQLConnection();
			PreparedStatement pst = con.prepareStatement(PropertyReader.getProperty(Constants.FIND_BY_PRID));
			pst.setInt(1, prId);
			pst.setString(2, methodName);
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				isExist = true;
			}
		}catch(Exception e) {
			logger.info("OWS_LOG : Exception Occurred in Method : isPRExist PRID="+prId +" msg= "+e.getMessage());
		}
		return isExist;
	}


	
}
