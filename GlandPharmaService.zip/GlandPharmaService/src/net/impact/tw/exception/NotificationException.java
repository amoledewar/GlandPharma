package net.impact.tw.exception;

public class NotificationException extends Exception {
	public NotificationException(String msg){
		super(msg);
		System.out.println(msg);
	}

}
