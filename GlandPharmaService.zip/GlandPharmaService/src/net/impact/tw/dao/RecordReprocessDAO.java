package net.impact.tw.dao;

import java.util.List;

import net.impact.tw.dto.RecordReprocessEntity;

public interface RecordReprocessDAO {
	
	public void addRecord(RecordReprocessEntity recordEntity) throws Exception;
	public List<RecordReprocessEntity> searchPendingRecordToProcess() throws Exception;
	public void updateProcessedRecord(RecordReprocessEntity recordEntity) throws Exception;
	public RecordReprocessEntity findById(int id) throws Exception;
	public boolean findByPRIDAndMethodName(int prId,String MethodName) throws Exception;
	
}
