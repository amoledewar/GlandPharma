package net.impact.tw.dao;

import com.sparta.webservices.axis2.TrackWiseStub;

public interface TrackWiseOperationDAO{
	
	public void createADEChild(int prId);
	public int createCompInvFormulationChild(int prId,String sessionId,TrackWiseStub tws) throws Exception;
	public int createCompInvAPIChild(int prId,String sessionId,TrackWiseStub tws) throws Exception;
	public int createCAPAFromMC(int prId,String sessionId,TrackWiseStub tws) throws Exception;
	public int createCAPAFROMRCI(int prId,String sessionId,TrackWiseStub tws) throws Exception;
	public int createInvActionChild(int prId,String sessionId,TrackWiseStub tws) throws Exception;
	public boolean setMetaDataForMCFormulation(int prId,String sessionId,TrackWiseStub tws) throws Exception;
	public boolean setOriginatingDept(int prId,String sessionId,TrackWiseStub tws) throws Exception;
	public int createCFTChild(int prId,String sessionId,TrackWiseStub tws) throws Exception;
	public int createRAAssessChild(int prId,String sessionId,TrackWiseStub tws) throws Exception;
	public int createAIChild(int prId,String sessionId,TrackWiseStub tws) throws Exception;
	public int createAdditionalAIChild(int prId,String sessionId,TrackWiseStub tws) throws Exception;
	public boolean copyChildGridToParent(int prId,String sessionId,TrackWiseStub tws) throws Exception;
}
