
/**
 * GlandPharmaOWSServiceMessageReceiverInOut.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.1  Built on : Aug 31, 2011 (12:22:40 CEST)
 */
package net.impact.tw.ows;

/**
 * GlandPharmaOWSServiceMessageReceiverInOut message receiver
 */

public class GlandPharmaOWSServiceMessageReceiverInOut extends org.apache.axis2.receivers.AbstractInOutMessageReceiver {

	public synchronized void invokeBusinessLogic(org.apache.axis2.context.MessageContext msgContext,
			org.apache.axis2.context.MessageContext newMsgContext) throws org.apache.axis2.AxisFault {

		try {

			// get the implementation class for the Web Service
			Object obj = getTheImplementationObject(msgContext);

			GlandPharmaOWSServiceSkeleton skel = (GlandPharmaOWSServiceSkeleton) obj;
			// Out Envelop
			org.apache.axiom.soap.SOAPEnvelope envelope = null;
			// Find the axisOperation that has been set by the Dispatch phase.
			org.apache.axis2.description.AxisOperation op = msgContext.getOperationContext().getAxisOperation();
			if (op == null) {
				throw new org.apache.axis2.AxisFault(
						"Operation is not located, if this is doclit style the SOAP-ACTION should specified via the SOAP Action to use the RawXMLProvider");
			}

			java.lang.String methodName;
			if ((op.getName() != null) && ((methodName = org.apache.axis2.util.JavaUtils
					.xmlNameToJavaIdentifier(op.getName().getLocalPart())) != null)) {

				if ("createCFTChild".equals(methodName)) {

					org.apache.axiom.om.OMElement createCFTChildResponse49 = null;
					org.apache.axiom.om.OMElement wrappedParam = (org.apache.axiom.om.OMElement) fromOM(
							msgContext.getEnvelope().getBody().getFirstElement(), org.apache.axiom.om.OMElement.class,
							getEnvelopeNamespaces(msgContext.getEnvelope()));

					createCFTChildResponse49 =

							skel.createCFTChild(wrappedParam);

					envelope = toEnvelope(getSOAPFactory(msgContext), createCFTChildResponse49, false,
							new javax.xml.namespace.QName("http://ows.trackwise.impact.net", "createCFTChild"));
				} else

				if ("createRAAssessChild".equals(methodName)) {

					org.apache.axiom.om.OMElement createRAAssessChildResponse51 = null;
					org.apache.axiom.om.OMElement wrappedParam = (org.apache.axiom.om.OMElement) fromOM(
							msgContext.getEnvelope().getBody().getFirstElement(), org.apache.axiom.om.OMElement.class,
							getEnvelopeNamespaces(msgContext.getEnvelope()));

					createRAAssessChildResponse51 =

							skel.createRAAssessChild(wrappedParam);

					envelope = toEnvelope(getSOAPFactory(msgContext), createRAAssessChildResponse51, false,
							new javax.xml.namespace.QName("http://ows.trackwise.impact.net", "createRAAssessChild"));
				} else

				if ("createCAPAFromMC".equals(methodName)) {

					org.apache.axiom.om.OMElement createCAPAFromMCResponse53 = null;
					org.apache.axiom.om.OMElement wrappedParam = (org.apache.axiom.om.OMElement) fromOM(
							msgContext.getEnvelope().getBody().getFirstElement(), org.apache.axiom.om.OMElement.class,
							getEnvelopeNamespaces(msgContext.getEnvelope()));

					createCAPAFromMCResponse53 =

							skel.createCAPAFromMC(wrappedParam);

					envelope = toEnvelope(getSOAPFactory(msgContext), createCAPAFromMCResponse53, false,
							new javax.xml.namespace.QName("http://ows.trackwise.impact.net", "createCAPAFromMC"));
				} else

				if ("createCAPAFromRCI".equals(methodName)) {

					org.apache.axiom.om.OMElement createCAPAFromRCIResponse55 = null;
					org.apache.axiom.om.OMElement wrappedParam = (org.apache.axiom.om.OMElement) fromOM(
							msgContext.getEnvelope().getBody().getFirstElement(), org.apache.axiom.om.OMElement.class,
							getEnvelopeNamespaces(msgContext.getEnvelope()));

					createCAPAFromRCIResponse55 =

							skel.createCAPAFromRCI(wrappedParam);

					envelope = toEnvelope(getSOAPFactory(msgContext), createCAPAFromRCIResponse55, false,
							new javax.xml.namespace.QName("http://ows.trackwise.impact.net", "createCAPAFromRCI"));
				} else

				if ("createCompInvAPIChild".equals(methodName)) {

					org.apache.axiom.om.OMElement createCompInvAPIChildResponse57 = null;
					org.apache.axiom.om.OMElement wrappedParam = (org.apache.axiom.om.OMElement) fromOM(
							msgContext.getEnvelope().getBody().getFirstElement(), org.apache.axiom.om.OMElement.class,
							getEnvelopeNamespaces(msgContext.getEnvelope()));

					createCompInvAPIChildResponse57 =

							skel.createCompInvAPIChild(wrappedParam);

					envelope = toEnvelope(getSOAPFactory(msgContext), createCompInvAPIChildResponse57, false,
							new javax.xml.namespace.QName("http://ows.trackwise.impact.net", "createCompInvAPIChild"));
				} else

				if ("copyChildGridToParent".equals(methodName)) {

					org.apache.axiom.om.OMElement copyChildGridToParentResponse59 = null;
					org.apache.axiom.om.OMElement wrappedParam = (org.apache.axiom.om.OMElement) fromOM(
							msgContext.getEnvelope().getBody().getFirstElement(), org.apache.axiom.om.OMElement.class,
							getEnvelopeNamespaces(msgContext.getEnvelope()));

					copyChildGridToParentResponse59 =

							skel.copyChildGridToParent(wrappedParam);

					envelope = toEnvelope(getSOAPFactory(msgContext), copyChildGridToParentResponse59, false,
							new javax.xml.namespace.QName("http://ows.trackwise.impact.net", "copyChildGridToParent"));
				} else

				if ("setOriginatingDept".equals(methodName)) {

					org.apache.axiom.om.OMElement setOriginatingDeptResponse61 = null;
					org.apache.axiom.om.OMElement wrappedParam = (org.apache.axiom.om.OMElement) fromOM(
							msgContext.getEnvelope().getBody().getFirstElement(), org.apache.axiom.om.OMElement.class,
							getEnvelopeNamespaces(msgContext.getEnvelope()));

					setOriginatingDeptResponse61 =

							skel.setOriginatingDept(wrappedParam);

					envelope = toEnvelope(getSOAPFactory(msgContext), setOriginatingDeptResponse61, false,
							new javax.xml.namespace.QName("http://ows.trackwise.impact.net", "setOriginatingDept"));
				} else

				if ("createAdditionalAIChild".equals(methodName)) {

					org.apache.axiom.om.OMElement createAdditionalAIChildResponse63 = null;
					org.apache.axiom.om.OMElement wrappedParam = (org.apache.axiom.om.OMElement) fromOM(
							msgContext.getEnvelope().getBody().getFirstElement(), org.apache.axiom.om.OMElement.class,
							getEnvelopeNamespaces(msgContext.getEnvelope()));

					createAdditionalAIChildResponse63 =

							skel.createAdditionalAIChild(wrappedParam);

					envelope = toEnvelope(getSOAPFactory(msgContext), createAdditionalAIChildResponse63, false,
							new javax.xml.namespace.QName("http://ows.trackwise.impact.net",
									"createAdditionalAIChild"));
				} else

				if ("createCompInvFormulationChild".equals(methodName)) {

					org.apache.axiom.om.OMElement createCompInvFormulationChildResponse65 = null;
					org.apache.axiom.om.OMElement wrappedParam = (org.apache.axiom.om.OMElement) fromOM(
							msgContext.getEnvelope().getBody().getFirstElement(), org.apache.axiom.om.OMElement.class,
							getEnvelopeNamespaces(msgContext.getEnvelope()));

					createCompInvFormulationChildResponse65 =

							skel.createCompInvFormulationChild(wrappedParam);

					envelope = toEnvelope(getSOAPFactory(msgContext), createCompInvFormulationChildResponse65, false,
							new javax.xml.namespace.QName("http://ows.trackwise.impact.net",
									"createCompInvFormulationChild"));
				} else

				if ("setMetaDataForMCFormulation".equals(methodName)) {

					org.apache.axiom.om.OMElement setMetaDataForMCFormulationResponse67 = null;
					org.apache.axiom.om.OMElement wrappedParam = (org.apache.axiom.om.OMElement) fromOM(
							msgContext.getEnvelope().getBody().getFirstElement(), org.apache.axiom.om.OMElement.class,
							getEnvelopeNamespaces(msgContext.getEnvelope()));

					setMetaDataForMCFormulationResponse67 =

							skel.setMetaDataForMCFormulation(wrappedParam);

					envelope = toEnvelope(getSOAPFactory(msgContext), setMetaDataForMCFormulationResponse67, false,
							new javax.xml.namespace.QName("http://ows.trackwise.impact.net",
									"setMetaDataForMCFormulation"));
				} else

				if ("createAIChild".equals(methodName)) {

					org.apache.axiom.om.OMElement createAIChildResponse69 = null;
					org.apache.axiom.om.OMElement wrappedParam = (org.apache.axiom.om.OMElement) fromOM(
							msgContext.getEnvelope().getBody().getFirstElement(), org.apache.axiom.om.OMElement.class,
							getEnvelopeNamespaces(msgContext.getEnvelope()));

					createAIChildResponse69 =

							skel.createAIChild(wrappedParam);

					envelope = toEnvelope(getSOAPFactory(msgContext), createAIChildResponse69, false,
							new javax.xml.namespace.QName("http://ows.trackwise.impact.net", "createAIChild"));
				} else

				if ("createInvActionChild".equals(methodName)) {

					org.apache.axiom.om.OMElement createInvActionChildResponse71 = null;
					org.apache.axiom.om.OMElement wrappedParam = (org.apache.axiom.om.OMElement) fromOM(
							msgContext.getEnvelope().getBody().getFirstElement(), org.apache.axiom.om.OMElement.class,
							getEnvelopeNamespaces(msgContext.getEnvelope()));

					createInvActionChildResponse71 =

							skel.createInvActionChild(wrappedParam);

					envelope = toEnvelope(getSOAPFactory(msgContext), createInvActionChildResponse71, false,
							new javax.xml.namespace.QName("http://ows.trackwise.impact.net", "createInvActionChild"));

				} else {
					throw new java.lang.RuntimeException("method not found");
				}

				newMsgContext.setEnvelope(envelope);
			}
		} catch (java.lang.Exception e) {
			throw org.apache.axis2.AxisFault.makeFault(e);
		}
	}

	//
	private org.apache.axiom.om.OMElement fromOM(org.apache.axiom.om.OMElement param, java.lang.Class type,
			java.util.Map extraNamespaces) throws org.apache.axis2.AxisFault {
		return param;
	}

	private org.apache.axiom.om.OMElement toOM(org.apache.axiom.om.OMElement param, boolean optimizeContent)
			throws org.apache.axis2.AxisFault {
		return param;
	}

	private org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory,
			org.apache.axiom.om.OMElement param, boolean optimizeContent, javax.xml.namespace.QName methodQName)
			throws org.apache.axis2.AxisFault {
		org.apache.axiom.soap.SOAPEnvelope envelope = factory.getDefaultEnvelope();
		envelope.getBody().addChild(param);
		return envelope;
	}

	/**
	 * get the default envelope
	 */
	private org.apache.axiom.soap.SOAPEnvelope toEnvelope(org.apache.axiom.soap.SOAPFactory factory)
			throws org.apache.axis2.AxisFault {
		return factory.getDefaultEnvelope();
	}

	/**
	 * A utility method that copies the namepaces from the SOAPEnvelope
	 */
	private java.util.Map getEnvelopeNamespaces(org.apache.axiom.soap.SOAPEnvelope env) {
		java.util.Map returnMap = new java.util.HashMap();
		java.util.Iterator namespaceIterator = env.getAllDeclaredNamespaces();
		while (namespaceIterator.hasNext()) {
			org.apache.axiom.om.OMNamespace ns = (org.apache.axiom.om.OMNamespace) namespaceIterator.next();
			returnMap.put(ns.getPrefix(), ns.getNamespaceURI());
		}
		return returnMap;
	}

	private org.apache.axis2.AxisFault createAxisFault(java.lang.Exception e) {
		org.apache.axis2.AxisFault f;
		Throwable cause = e.getCause();
		if (cause != null) {
			f = new org.apache.axis2.AxisFault(e.getMessage(), cause);
		} else {
			f = new org.apache.axis2.AxisFault(e.getMessage());
		}

		return f;
	}

}// end of class
