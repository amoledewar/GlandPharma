
/**
 * GlandPharmaOWSServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.1  Built on : Aug 31, 2011 (12:22:40 CEST)
 */
package net.impact.tw.ows;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axiom.om.OMNamespace;
import org.apache.log4j.Logger;

import com.sparta.webservices.axis2.TWSException;
import com.sparta.webservices.axis2.TrackWiseStub;

import net.impact.tw.helper.GPServiceConnection;
import net.impact.tw.helper.OWSUtil;
import net.impact.tw.imple.TrackWiseOperationImple;
import net.impact.tw.constants.*;

/**
 * GlandPharmaOWSServiceSkeleton java skeleton for the axisService
 */
public class GlandPharmaOWSServiceSkeleton {

	Logger logger;
	GPServiceConnection data;
	TrackWiseOperationImple twOpr = new TrackWiseOperationImple();
	
	public GlandPharmaOWSServiceSkeleton() {
		this.logger = Logger.getLogger((Class) GlandPharmaOWSServiceSkeleton.class);
		this.data = new GPServiceConnection();
	}
	
	
	/**
	 * Auto generated method signature createCompInvFormChild
	 * 
	 * @param createCompInvFormulationChildRequest
	 * @return createCompInvFormulationChildResponse
	 * @throws Exception 
	 */

	public org.apache.axiom.om.OMElement createCompInvFormulationChild(org.apache.axiom.om.OMElement createCompInvFormulationChildRequest) throws Exception {
		
		logger.info("OWS_MSG : OUTSIDE THE SYNCHRONISED BLOCK..!!");	
		synchronized (this) {
			logger.info("OWS_MSG: FIRST LINE IN METHOD createCompInvFormulationChild");
			OMFactory fac = OMAbstractFactory.getOMFactory();
			OMNamespace ns = createCompInvFormulationChildRequest.getNamespace();
			OMElement response = fac.createOMElement("createCompInvFormulationChildResponse", ns);
			String parentPrIdStr = OWSUtil.parseChild(createCompInvFormulationChildRequest, Constants.PRID);
			int parentPRId = Integer.parseInt(parentPrIdStr);
			logger.info("IN METHOD createCompInvFormulationChild Parent PR Id : " + parentPRId);
			String sessionId = null;
			TrackWiseStub tws = null;
			try {
				sessionId = this.data.createSession();
				tws = this.data.getTrackWiseStub();
				twOpr.createCompInvFormulationChild(parentPRId,sessionId,tws);
				
			}catch(TWSException twe) {
				logger.info("OWS_MSG : MSG : "+twe.getMessage()+" FAULT_MSG : "+twe.getFaultMessage());
			}finally {
				this.data.closeSession(sessionId);
				logger.info("Session Closed successfully IN METHOD createCompInvFormulationChild .!!");
			}
			return response;
		}
		
	}

	/**
	 * Auto generated method signature
	 * 
	 * @param createCompInvAPIChildRequest
	 * @return createCompInvAPIChildResponse
	 * @throws Exception 
	 */

	public org.apache.axiom.om.OMElement createCompInvAPIChild(org.apache.axiom.om.OMElement createCompInvAPIChildRequest) throws Exception {
			
		// TODO : fill this with the necessary business logic
		logger.info("OWS_MSG : OUTSIDE THE SYNCHRONISED BLOCK..!! IN METHOD createCompInvAPIChild");
		synchronized (this) {
			OMFactory fac = OMAbstractFactory.getOMFactory();
			OMNamespace ns = createCompInvAPIChildRequest.getNamespace();
			OMElement response = fac.createOMElement("createCompInvAPIChildResponse", ns);
			String parentPrIdStr = OWSUtil.parseChild(createCompInvAPIChildRequest, Constants.PRID);
			int parentPRId = Integer.parseInt(parentPrIdStr);
			logger.info("IN METHOD createCompInvAPIChild Parent PR Id : " + parentPRId);
			String sessionId = null;
			TrackWiseStub tws = null;
			try {
				sessionId = this.data.createSession();
				tws = this.data.getTrackWiseStub();
				twOpr.createCompInvAPIChild(parentPRId, sessionId, tws);
				
			}catch(TWSException twe) {
				logger.info("OWS_MSG : MSG : "+twe.getMessage()+" FAULT_MSG : "+twe.getFaultMessage());
			}finally {
				this.data.closeSession(sessionId);
				logger.info("Session Closed successfully IN METHOD createCompInvAPIChild .!!");
			}
			return response;
		}
	}
	
	
	/**
	 * Auto generated method signature
	 * 
	 * @param createCAPAChildRequest
	 * @return createCAPAChildResponse
	 * @throws Exception 
	 */

	public org.apache.axiom.om.OMElement createCAPAFromMC(org.apache.axiom.om.OMElement createCAPAChildRequest) throws Exception {
		// TODO : fill this with the necessary business logic
		logger.info("OWS_MSG : OUTSIDE THE SYNCHRONISED BLOCK..!! IN METHOD createCAPAChild");
		synchronized (this) {
			OMFactory fac = OMAbstractFactory.getOMFactory();
			OMNamespace ns = createCAPAChildRequest.getNamespace();
			OMElement response = fac.createOMElement("createCAPAChildResponse", ns);
			String parentPrIdStr = OWSUtil.parseChild(createCAPAChildRequest, Constants.PRID);
			int parentPRId = Integer.parseInt(parentPrIdStr);
			logger.info("IN METHOD createCAPAChild Parent PR Id : " + parentPRId);
			String sessionId = null;
			TrackWiseStub tws = null;
			try {
				sessionId = this.data.createSession();
				tws = this.data.getTrackWiseStub();
				twOpr.createCAPAFromMC(parentPRId, sessionId, tws);
				
			}catch(TWSException twe) {
				logger.info("PRID : "+parentPRId+"OWS_MSG : "+twe.getMessage()+" FAULT_MSG : "+twe.getFaultMessage());
			}finally {
				this.data.closeSession(sessionId);
				logger.info("Session Closed successfully IN METHOD createCAPAChild .!!");
			}
			return response;
		}
	}
	
	
	/**
	 * Auto generated method signature
	 * 
	 * @param createInvActionChildRequest
	 * @return createInvActionChildResponse
	 * @throws Exception 
	 */

	public org.apache.axiom.om.OMElement createInvActionChild(org.apache.axiom.om.OMElement createInvActionChildRequest) throws Exception {
		logger.info("OWS_MSG : OUTSIDE THE SYNCHRONISED BLOCK..!! IN METHOD createInvActionChild");	
		synchronized (this) {
			OMFactory fac = OMAbstractFactory.getOMFactory();
			OMNamespace ns = createInvActionChildRequest.getNamespace();
			OMElement response = fac.createOMElement("createInvActionChildResponse", ns);
			String parentPrIdStr = OWSUtil.parseChild(createInvActionChildRequest, Constants.PRID);
			int parentPRId = Integer.parseInt(parentPrIdStr);
			logger.info("IN METHOD createCAPAChild Parent PR Id : " + parentPRId);
			String sessionId = null;
			TrackWiseStub tws = null;
			try {
				sessionId = this.data.createSession();
				tws = this.data.getTrackWiseStub();
				twOpr.createInvActionChild(parentPRId, sessionId, tws);
				
			}catch(TWSException twe) {
				logger.info("PRID : "+parentPRId+"OWS_MSG : "+twe.getMessage()+" FAULT_MSG : "+twe.getFaultMessage());
			}finally {
				this.data.closeSession(sessionId);
				logger.info("Session Closed successfully IN METHOD createCAPAChild .!!");
			}
			return response;
		}
	}
	
	
	/**
	 * Auto generated method signature
	 * 
	 * @param setMetaDataForMCFormulationRequest
	 * @return setMetaDataForMCFormulationResponse
	 * @throws Exception 
	 */

	public org.apache.axiom.om.OMElement setMetaDataForMCFormulation(org.apache.axiom.om.OMElement setMetaDataForMCFormulationRequest) throws Exception {
			
		logger.info("OWS_MSG : OUTSIDE THE SYNCHRONISED BLOCK..!! IN METHOD setMetaDataForMCFormulation");
		synchronized (this) {
			OMFactory fac = OMAbstractFactory.getOMFactory();
			OMNamespace ns = setMetaDataForMCFormulationRequest.getNamespace();
			OMElement response = fac.createOMElement("setMetaDataForMCFormulationResponse", ns);
			String parentPrIdStr = OWSUtil.parseChild(setMetaDataForMCFormulationRequest, Constants.PRID);
			int parentPRId = Integer.parseInt(parentPrIdStr);
			logger.info("IN METHOD setMetaDataForMCFormulation Parent PR Id : " + parentPRId);
			String sessionId = null;
			TrackWiseStub tws = null;
			try {
				sessionId = this.data.createSession();
				tws = this.data.getTrackWiseStub();
				twOpr.setMetaDataForMCFormulation(parentPRId, sessionId, tws);
				
			}catch(TWSException twe) {
				logger.info("OWS_MSG : MSG : "+twe.getMessage()+" FAULT_MSG : "+twe.getFaultMessage());
			}finally {
				this.data.closeSession(sessionId);
				logger.info("Session Closed successfully IN METHOD setMetaDataForMCFormulation .!!");
			}
			return response;
		}
	}
	
	
	/**
	 * Auto generated method signature
	 * 
	 * @param createCAPAFromRCIRequest
	 * @return createCAPAFromRCIResponse
	 * @throws Exception 
	 */

	public org.apache.axiom.om.OMElement createCAPAFromRCI(org.apache.axiom.om.OMElement createCAPAFromRCIRequest) throws Exception {
		logger.info("OWS_MSG : OUTSIDE THE SYNCHRONISED BLOCK..!! IN METHOD createCAPAFromRCI");
		synchronized (this) {
			OMFactory fac = OMAbstractFactory.getOMFactory();
			OMNamespace ns = createCAPAFromRCIRequest.getNamespace();
			OMElement response = fac.createOMElement("createCAPAFromRCIResponse", ns);
			String parentPrIdStr = OWSUtil.parseChild(createCAPAFromRCIRequest, Constants.PRID);
			int parentPRId = Integer.parseInt(parentPrIdStr);
			logger.info("IN METHOD setMetaDataForMCFormulation Parent PR Id : " + parentPRId);
			String sessionId = null;
			TrackWiseStub tws = null;
			try {
				sessionId = this.data.createSession();
				tws = this.data.getTrackWiseStub();
				twOpr.createCAPAFROMRCI(parentPRId, sessionId, tws);
				
			}catch(TWSException twe) {
				logger.info("OWS_MSG : MSG : "+twe.getMessage()+" FAULT_MSG : "+twe.getFaultMessage());
			}finally {
				this.data.closeSession(sessionId);
				logger.info("Session Closed successfully IN METHOD setMetaDataForMCFormulation .!!");
			}
			return response;
		}
	}
	
	
	
	/**
	 * Auto generated method signature
	 * 
	 * @param setOriginatingDeptRequest
	 * @return setOriginatingDeptResponse
	 * @throws Exception 
	 */

	public org.apache.axiom.om.OMElement setOriginatingDept(org.apache.axiom.om.OMElement setOriginatingDeptRequest) throws Exception {
		logger.info("OWS_MSG : OUTSIDE THE SYNCHRONISED BLOCK..!! IN METHOD setOriginatingDept");
		synchronized (this) {
			OMFactory fac = OMAbstractFactory.getOMFactory();
			OMNamespace ns = setOriginatingDeptRequest.getNamespace();
			OMElement response = fac.createOMElement("setOriginatingDeptResponse", ns);
			String parentPrIdStr = OWSUtil.parseChild(setOriginatingDeptRequest, Constants.PRID);
			int parentPRId = Integer.parseInt(parentPrIdStr);
			logger.info("IN METHOD setOriginatingDept Parent PR Id : " + parentPRId);
			String sessionId = null;
			TrackWiseStub tws = null;
			try {
				sessionId = this.data.createSession();
				tws = this.data.getTrackWiseStub();
				twOpr.setOriginatingDept(parentPRId, sessionId, tws);
				
			}catch(TWSException twe) {
				logger.info("OWS_MSG : MSG : "+twe.getMessage()+" FAULT_MSG : "+twe.getFaultMessage());
			}finally {
				this.data.closeSession(sessionId);
				logger.info("Session Closed successfully IN METHOD setOriginatingDept .!!");
			}
			return response;
		}
	}
	
	
	/**
	 * Auto generated method signature
	 * 
	 * @param createCFTChildRequest
	 * @return createCFTChildResponse
	 * @throws Exception 
	 */

	public org.apache.axiom.om.OMElement createCFTChild(org.apache.axiom.om.OMElement createCFTChildRequest) throws Exception {
		logger.info("OWS_MSG : OUTSIDE THE SYNCHRONISED BLOCK..!!");
		synchronized (this) {
			logger.info("OWS_MSG: FIRST LINE IN METHOD createCFTChild");
			OMFactory fac = OMAbstractFactory.getOMFactory();
			OMNamespace ns = createCFTChildRequest.getNamespace();
			OMElement response = fac.createOMElement("createCFTChildResponse", ns);
			String parentPrIdStr = OWSUtil.parseChild(createCFTChildRequest, Constants.PRID);
			int parentPRId = Integer.parseInt(parentPrIdStr);
			logger.info("IN METHOD createCFTChild Parent PR Id : " + parentPRId);
			String sessionId = null;
			TrackWiseStub tws = null;
			try {
				sessionId = this.data.createSession();
				tws = this.data.getTrackWiseStub();
				twOpr.createCFTChild(parentPRId,sessionId,tws);
				
			}catch(TWSException twe) {
				logger.info("OWS_MSG : MSG : "+twe.getMessage()+" FAULT_MSG : "+twe.getFaultMessage());
			}finally {
				this.data.closeSession(sessionId);
				logger.info("Session Closed successfully IN METHOD createCFTChild .!!");
			}
			return response;
		}
	}
	
	/**
	 * Auto generated method signature
	 * 
	 * @param createRAAssessChildRequest
	 * @return createRAAssessChildResponse
	 * @throws Exception 
	 */

	public org.apache.axiom.om.OMElement createRAAssessChild(org.apache.axiom.om.OMElement createRAAssessChildRequest) throws Exception {
		logger.info("OWS_MSG : OUTSIDE THE SYNCHRONISED BLOCK..!!");
		synchronized (this) {
			logger.info("OWS_MSG: FIRST LINE IN METHOD createRAAssessChild");
			OMFactory fac = OMAbstractFactory.getOMFactory();
			OMNamespace ns = createRAAssessChildRequest.getNamespace();
			OMElement response = fac.createOMElement("createRAAssessChildResponse", ns);
			String parentPrIdStr = OWSUtil.parseChild(createRAAssessChildRequest, Constants.PRID);
			int parentPRId = Integer.parseInt(parentPrIdStr);
			logger.info("IN METHOD createRAAssessChild Parent PR Id : " + parentPRId);
			String sessionId = null;
			TrackWiseStub tws = null;
			try {
				sessionId = this.data.createSession();
				tws = this.data.getTrackWiseStub();
				twOpr.createRAAssessChild(parentPRId,sessionId,tws);
				
			}catch(TWSException twe) {
				logger.info("OWS_MSG : MSG : "+twe.getMessage()+" FAULT_MSG : "+twe.getFaultMessage());
			}finally {
				this.data.closeSession(sessionId);
				logger.info("Session Closed successfully IN METHOD createRAAssessChild .!!");
				
			}
			return response;
		}
	}
	
	
	/**
	 * Auto generated method signature
	 * 
	 * @param createAIChildRequest
	 * @return createAIChildResponse
	 * @throws Exception 
	 */

	public org.apache.axiom.om.OMElement createAIChild(org.apache.axiom.om.OMElement createAIChildRequest) throws Exception {
		logger.info("OWS_MSG : OUTSIDE THE SYNCHRONISED BLOCK..!!");
		synchronized (this) {
			logger.info("OWS_MSG: FIRST LINE IN METHOD createAIChild");
			OMFactory fac = OMAbstractFactory.getOMFactory();
			OMNamespace ns = createAIChildRequest.getNamespace();
			OMElement response = fac.createOMElement("createAIChildResponse", ns);
			String parentPrIdStr = OWSUtil.parseChild(createAIChildRequest, Constants.PRID);
			int parentPRId = Integer.parseInt(parentPrIdStr);
			logger.info("IN METHOD createAIChild Parent PR Id : " + parentPRId);
			String sessionId = null;
			TrackWiseStub tws = null;
			try {
				sessionId = this.data.createSession();
				tws = this.data.getTrackWiseStub();
				twOpr.createAIChild(parentPRId,sessionId,tws);
				
			}catch(TWSException twe) {
				logger.info("OWS_MSG : MSG : "+twe.getMessage()+" FAULT_MSG : "+twe.getFaultMessage());
			}finally {
				this.data.closeSession(sessionId);
				logger.info("Session Closed successfully IN METHOD createAIChild .!!");
			}
			return response;
		}
	}
	
	/**
	 * Auto generated method signature
	 * 
	 * @param createAdditionalAIChildRequest
	 * @return createAdditionalAIChildResponse
	 * @throws Exception 
	 */

	public org.apache.axiom.om.OMElement createAdditionalAIChild(org.apache.axiom.om.OMElement createAdditionalAIChildRequest) throws Exception {
			
		logger.info("OWS_MSG : OUTSIDE THE SYNCHRONISED BLOCK..!!");
		synchronized (this) {
			logger.info("OWS_MSG: FIRST LINE IN METHOD createAdditionalAIChild");
			OMFactory fac = OMAbstractFactory.getOMFactory();
			OMNamespace ns = createAdditionalAIChildRequest.getNamespace();
			OMElement response = fac.createOMElement("createAdditionalAIChildResponse", ns);
			String parentPrIdStr = OWSUtil.parseChild(createAdditionalAIChildRequest, Constants.PRID);
			int parentPRId = Integer.parseInt(parentPrIdStr);
			logger.info("IN METHOD createAdditionalAIChild Parent PR Id : " + parentPRId);
			String sessionId = null;
			TrackWiseStub tws = null;
			try {
				sessionId = this.data.createSession();
				tws = this.data.getTrackWiseStub();
				twOpr.createAdditionalAIChild(parentPRId,sessionId,tws);
				
			}catch(TWSException twe) {
				logger.info("OWS_MSG : MSG : "+twe.getMessage()+" FAULT_MSG : "+twe.getFaultMessage());
			}finally {
				this.data.closeSession(sessionId);
				logger.info("Session Closed successfully IN METHOD createAdditionalAIChild .!!");
			}
			return response;
		}
	}
	
	/**
	 * Auto generated method signature
	 * 
	 * @param copyChildGridToParentRequest
	 * @return copyChildGridToParentResponse
	 * @throws Exception 
	 */

	public org.apache.axiom.om.OMElement copyChildGridToParent(org.apache.axiom.om.OMElement copyChildGridToParentRequest) throws Exception {
			
		logger.info("OWS_MSG : OUTSIDE THE SYNCHRONISED BLOCK..!!");
		synchronized (this) {
			logger.info("OWS_MSG: FIRST LINE IN METHOD copyChildGridToParent");
			OMFactory fac = OMAbstractFactory.getOMFactory();
			OMNamespace ns = copyChildGridToParentRequest.getNamespace();
			OMElement response = fac.createOMElement("copyChildGridToParentResponse", ns);
			String parentPrIdStr = OWSUtil.parseChild(copyChildGridToParentRequest, Constants.PRID);
			int parentPRId = Integer.parseInt(parentPrIdStr);
			logger.info("IN METHOD copyChildGridToParent Parent PR Id : " + parentPRId);
			String sessionId = null;
			TrackWiseStub tws = null;
			try {
				sessionId = this.data.createSession();
				tws = this.data.getTrackWiseStub();
				twOpr.copyChildGridToParent(parentPRId,sessionId,tws);
				
			}catch(TWSException twe) {
				logger.info("OWS_MSG : MSG : "+twe.getMessage()+" FAULT_MSG : "+twe.getFaultMessage());
			}finally {
				this.data.closeSession(sessionId);
				logger.info("Session Closed successfully IN METHOD copyChildGridToParent .!!");
			}
			return response;
		}
	}
	
}
