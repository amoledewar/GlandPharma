package net.impact.tw.helper;

import java.io.InputStream;
import java.util.Properties;
import java.io.IOException;

public class PropertyReader {
	private static Properties prop = null;

	private PropertyReader() {
	}

	protected static void loadProperties() {
		InputStream inputStream = null;
		try {
			prop = new Properties();
			inputStream = PropertyReader.class.getClassLoader().getResourceAsStream("Config.properties");
			prop.load(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static String getProperty(String propertyName) {
		if (prop == null)
			loadProperties();
		String label = "";

		label = prop.getProperty(propertyName);
		if (label == null) {
			label = "";
		}
		return label;
	}
}