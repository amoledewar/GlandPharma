package net.impact.tw.helper;

import org.apache.axis2.AxisFault;
import com.sparta.webservices.axis2.TWSException;
import java.rmi.RemoteException;
import org.apache.commons.httpclient.HttpConnectionManager;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import com.sparta.webservices.axis2.TrackWiseStub;
import net.impact.tw.constants.Constants;
import net.impact.tw.exception.NotificationException;
import org.apache.log4j.Logger;

public class GPServiceConnection {

	Logger logger;
    private static String sURL;
    private static String sMaxConnections;
    private static String sTimeout;
    private static String sUser;
    private static String sPass;
    private static String sTimeZone;
    private static TrackWiseStub trackWiseStub;
    
    static {
        try {
        	GPServiceConnection.sURL = PropertyReader.getProperty(Constants.TWS_URL);
        	GPServiceConnection.sMaxConnections = PropertyReader.getProperty(Constants.TWS_MAX_CONN);
        	GPServiceConnection.sTimeout = PropertyReader.getProperty(Constants.TWS_TIMEOUT);
        	GPServiceConnection.sUser = PropertyReader.getProperty(Constants.USER_NAME);
        	GPServiceConnection.sPass = PropertyReader.getProperty(Constants.USER_PASSWORD);
        	GPServiceConnection.sTimeZone =PropertyReader.getProperty(Constants.USER_TIMEZONE);
        	GPServiceConnection.trackWiseStub = new TrackWiseStub(GPServiceConnection.sURL);
        	GPServiceConnection.trackWiseStub._getServiceClient().getOptions().setTimeOutInMilliSeconds((long)(1000 * new Integer(GPServiceConnection.sTimeout)));
            final MultiThreadedHttpConnectionManager conmgr = new MultiThreadedHttpConnectionManager();
            conmgr.getParams().setDefaultMaxConnectionsPerHost((int)new Integer(GPServiceConnection.sMaxConnections));
            final HttpClient client = new HttpClient((HttpConnectionManager)conmgr);
            GPServiceConnection.trackWiseStub._getServiceClient().getServiceContext().getConfigurationContext().setProperty(Constants.CACHED_HTTP_CLIENT, (Object)client);
            GPServiceConnection.trackWiseStub._getServiceClient().getServiceContext().getConfigurationContext().setProperty(Constants.REUSE_HTTP_CLIENT, (Object)"true");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public GPServiceConnection() {
        this.logger = Logger.getLogger((Class)GPServiceConnection.class);
    }
    
    /*
     * To Create sessionId for trackWise connection.
     * */
    public String createSession() throws Exception {
        this.logger.info((Object)"Locating TWS...");
        System.out.println("uname-->"+GPServiceConnection.sUser+" pwd : "+GPServiceConnection.sPass+" timezone : "+GPServiceConnection.sTimeZone);
        final String sessionId = GPServiceConnection.trackWiseStub.createSession(GPServiceConnection.sUser, GPServiceConnection.sPass, GPServiceConnection.sTimeZone);
        this.logger.info((Object)("sSessionId=" + sessionId));
        return sessionId;
    }
    
    /*
     * To get TrackWise object.
     * */
    public TrackWiseStub getTrackWiseStub() {
        return GPServiceConnection.trackWiseStub;
    }
    
    /*
     * To close TrackWise Session
     * Input Parameter sessionId
     * */
    
         
    public void closeSession(final String sessionId) throws NotificationException {
        if (GPServiceConnection.trackWiseStub != null && sessionId != null) {
            try {
            	GPServiceConnection.trackWiseStub.endSession(sessionId);
            }
            catch (RemoteException e) {
                this.logger.error((Object)Constants.ERROR_TER_SESSION, (Throwable)e);
                e.printStackTrace();
                throw new NotificationException(e.getMessage());
            }
            catch (TWSException e2) {
                this.logger.error((Object)Constants.ERROR_TER_SESSION, (Throwable)e2);
                e2.printStackTrace();
                throw new NotificationException(e2.getMessage());
            }
            try {
            	GPServiceConnection.trackWiseStub._getServiceClient().cleanupTransport();
            }
            catch (AxisFault e3) {
                this.logger.error((Object)Constants.ERROR_TER_SESSION, (Throwable)e3);
            }
        }
    }
    
    
    /*
     * To Create sessionId for trackWise connection For Re-Process Mechanism.
     * */
    public String createSessionForReprocess(String uname,String password) throws Exception {
        this.logger.info((Object)"Call From Re-process mechanism Locating TWS...");
        System.out.println("uname-->"+uname+" pwd : "+password+" timezone : "+GPServiceConnection.sTimeZone);
        final String sessionId = GPServiceConnection.trackWiseStub.createSession(uname, password, GPServiceConnection.sTimeZone);
        this.logger.info((Object)("sSessionId=" + sessionId));
        return sessionId;
    }


}
