package net.impact.tw.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.sparta.webservices.axis2.fields.ComplexType;
import com.sparta.webservices.axis2.fields.DateField;
import com.sparta.webservices.axis2.fields.Field;
import com.sparta.webservices.axis2.fields.PR;
import com.sparta.webservices.axis2.fields.SelectionField;
import com.sparta.webservices.axis2.fields.Util;

import net.impact.tw.constants.Constants;
import net.impact.tw.exception.NotificationException;

public class DBHandler {
	
	static Logger log = Logger.getLogger(DBHandler.class);
	
	public static final String SQL_QUERY_GET_MULTIPERSON_FIELD = PropertyReader.getProperty(Constants.GET_MULTIPERSON_ROLE); 
	public static final String SQL_QUERY_DEPT =  PropertyReader.getProperty(Constants.GET_DEPARTMENT);
	public static final String SQL_QUERY_GETCHILD_PR = PropertyReader.getProperty(Constants.GET_CHILD_PR);
	
	public Connection getSQLConnection() {
		Connection con = null;
		try {
			Class.forName(PropertyReader.getProperty(Constants.SQL_CLASS_NAME).trim());
			String serverUrl = PropertyReader.getProperty(Constants.SQL_CONECTION_STRING).trim();
			String sqlUser = PropertyReader.getProperty(Constants.SQL_USER).trim();
			String sqlPassword = PropertyReader.getProperty(Constants.SQL_PASSWORD).trim();
			con = DriverManager.getConnection(serverUrl, sqlUser, sqlPassword);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	
	public List<Integer> getChildPrId(Connection sqlConnection, int parentPrId) throws NotificationException {
		List<Integer> prIds = new ArrayList<Integer>();
		log.info("ENTER_IN_METHOD : GETCHILDPRID");
		ResultSet rs;
		StringBuilder selectQuery = new StringBuilder();
		try	{						 
			selectQuery.append(SQL_QUERY_GETCHILD_PR);
			PreparedStatement stmt = sqlConnection.prepareStatement(selectQuery.toString());;
			stmt.setInt(1, parentPrId);				
			rs = stmt.executeQuery();
			while(rs.next()) {
				prIds.add(rs.getInt("ID"));
			}
		}
		catch(Exception e) {
			log.info("ERROR OCCURRED IN DBHANDLER GETCHILDPRID : "+e.getMessage());
			throw new NotificationException("EXCEPTION OCCURRED : "+e.getMessage());
		}
		log.info("EXIT_FROM_METHOD : GETCHILDPRID");
		return prIds;
	}
	
	
	public List<String> getDepartment(Connection sqlConnection, int personId) {
		log.info("ENTERED IN METHOD : getDepartment");
		ResultSet rs;
		StringBuilder selectQuery = new StringBuilder();
		List<String> deptList = new ArrayList<String>();
		try {
			selectQuery.append(SQL_QUERY_DEPT);
			PreparedStatement stmt = sqlConnection.prepareStatement(selectQuery.toString());
			stmt.setInt(1, personId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				deptList.add(rs.getString("NAME"));
			}
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		log.info("EXIT FROM METHOD : getDepartment");
		return deptList;
	}
	
	
	public List<Integer> getMultiPersonFieldForChild(Connection sqlConnection,String personRoleType, String department,int divId,int prjId) {
		System.out.println("personRoleType : "+personRoleType+" department : "+department+" divId :"+divId+" prjId:"+prjId);
		log.info("ENTER_IN_METHOD : GETMULTIPERSONFIELDFORCHILD");
		ResultSet rs;
		StringBuilder selectQuery = new StringBuilder();
		List<Integer> personInfo = new ArrayList<Integer>();
		try {
				selectQuery.append(SQL_QUERY_GET_MULTIPERSON_FIELD);
				PreparedStatement stmt = sqlConnection.prepareStatement(selectQuery.toString());
				stmt.setString(1, personRoleType);
				stmt.setString(2, department);
				stmt.setInt(3, prjId);
				stmt.setInt(4, divId);
				rs = stmt.executeQuery();
				while (rs.next()) {
					personInfo.add(rs.getInt("PERSON_ID"));
				}
		} catch (Exception e) {
			log.info("EXCEPTION_OCCURRED_IN_GETMULTIPERSONFIELDFORCHILD : "+e.getMessage());
			e.printStackTrace();
		}

		log.info("EXIT_FROM_METHOD : GETMULTIPERSONFIELDFORCHILD");
		return personInfo;
	}
	
	
	public  boolean checkRecord(int prId) {
		boolean islock = false;
		log.info("ENTER_IN_METHOD : checkRecord PRId :"+prId);
		ResultSet rs;
		StringBuilder selectQuery = new StringBuilder();
		try {
			Connection sqlConnection = getSQLConnection();
			String query = "select * from Locks where id="+prId;
			selectQuery.append(SQL_QUERY_GET_MULTIPERSON_FIELD);
			PreparedStatement stmt = sqlConnection.prepareStatement(query);
			rs = stmt.executeQuery();
			while (rs.next()) {
				islock = true;
			}
		}catch (Exception e) {
			log.info("OWS_LOG : EXCEPTION IN METHOD : checkRecord MSG:"+e.getMessage());
		}
		return islock;
	}

			
}
