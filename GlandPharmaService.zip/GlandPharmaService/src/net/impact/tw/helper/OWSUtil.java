package net.impact.tw.helper;

import java.util.Iterator;
import java.util.Set;

import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axiom.om.OMNamespace;
import org.apache.axiom.om.OMText;
import org.apache.commons.validator.GenericValidator;
import org.apache.log4j.Logger;

public class OWSUtil {

	private static final Logger logger = Logger.getLogger(OWSUtil.class);

	public static String parseChild(OMElement parentOM, String childName) {
		OMElement childOM = getFirstChildWithLocalName(parentOM, childName);
		if (childOM == null)
			return null;
		return childOM.getText();
	}

	private static OMElement getFirstChildWithLocalName(OMElement parentOM, String childName) {
		Iterator<OMElement> children = parentOM.getChildElements();

		if (!children.hasNext()) {
			return null;
		}
		OMElement firstOM = null;
		while (children.hasNext()) {
			firstOM = (OMElement) children.next();
			if (firstOM.getLocalName().equals(childName)) {
				return firstOM;
			}
		}

		return null;
	}

	public static OMElement addChild(OMFactory factory, OMNamespace ns, OMElement parentOM, String childName,
			String childValue) {
		if (GenericValidator.isBlankOrNull(childValue)) {
			childValue = "";
		}

		OMElement childOM = factory.createOMElement(childName, ns);
		OMText textOM = factory.createOMText("<![CDATA[" + childValue + "]]>");
		childOM.addChild(textOM);
		parentOM.addChild(childOM);

		return parentOM;
	}

	public static OMElement addMultiChild(OMFactory factory, OMElement parentOM, String childName,
			Set<String> childValues) {

		if (childValues != null) {
			OMNamespace nullNS = factory.createOMNamespace("", "");
			OMElement childOM = factory.createOMElement(childName, nullNS);
			OMElement multiValueOM = factory.createOMElement("multivalue", nullNS);
			childOM.addChild(multiValueOM);
			parentOM.addChild(childOM);
			Iterator<String> values = childValues.iterator();
			while (values.hasNext()) {
				OMElement valueOM = factory.createOMElement("value", nullNS);
				OMText textOM = factory.createOMText("<![CDATA[" + values.next() + "]]>");
				valueOM.addChild(textOM);
				multiValueOM.addChild(valueOM);
			}
		}
		return parentOM;
	}

}