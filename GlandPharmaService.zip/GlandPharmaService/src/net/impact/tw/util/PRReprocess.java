package net.impact.tw.util;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.sparta.webservices.axis2.TrackWiseStub;

import net.impact.tw.constants.Constants;
import net.impact.tw.dto.RecordReprocessEntity;
import net.impact.tw.helper.GPServiceConnection;
import net.impact.tw.helper.PropertyReader;
import net.impact.tw.imple.RecordReprocessImple;
import net.impact.tw.imple.TrackWiseOperationImple;

public class PRReprocess {

	static Logger logger;
	static GPServiceConnection data;
	
	static {
		System.out.println("In Static blocl..!!!");
		logger = Logger.getLogger((Class) PRReprocess.class);
		data = new GPServiceConnection();
	}
	
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		logger.info("RE-PROCESS_LOG : IN PRReprocess Method !!!..");                                            
		String user =  PropertyReader.getProperty(Constants.REPROCESS_USER);
		String password =  PropertyReader.getProperty(Constants.REPROCESS_PASSWORD);
		String sessionId = data.createSessionForReprocess(user, password);
		TrackWiseStub tws = data.getTrackWiseStub();;
		logger.info("RE-PROCESS_LOG : In Re-Process Mechanism sessionId---->"+sessionId);
		TrackWiseOperationImple impl = new TrackWiseOperationImple();
		try {
			List<RecordReprocessEntity> pendingRecordList = RecordReprocessImple.getInstance().searchPendingRecordToProcess();
			logger.info("RE-PROCESS_LOG : Total Pending Records Is : "+pendingRecordList != null ? pendingRecordList.size(): 0);
			if(pendingRecordList != null && pendingRecordList.size()>0) {
				Iterator<RecordReprocessEntity> itr = pendingRecordList.iterator();
				while(itr.hasNext()) {
					RecordReprocessEntity processEntity = itr.next();
					String failedMethodName = processEntity.getMethodName();
					int id = processEntity.getId();
					if(failedMethodName.equals("createCompInvFormulationChild")) {
						logger.info("RE-PROCESS_LOG : Method 'createCompInvFormulationChild' calling from Re-Process mechanism");
						int newchildPrId = impl.createCompInvFormulationChild(processEntity.getPrId(), sessionId, tws);
						if(newchildPrId>0) {
							updateProcessedRecord(id);
							logger.info("RE-PROCESS_LOG : Record Re-processed Successfully.!! FOR PRID : "+processEntity.getPrId());
						}else {
							logger.info("RE-PROCESS_LOG : Record is not Re-processed..!! FOR PRID : "+processEntity.getPrId());
						}
						
					}else if(failedMethodName.equals("createCompInvAPIChild")) {
						logger.info("RE-PROCESS_LOG : Method 'createCompInvAPIChild' calling from Re-Process mechanism");
						int newChildPrId = impl.createCompInvAPIChild(processEntity.getPrId(), sessionId, tws);
						if(newChildPrId>0) {
							updateProcessedRecord(id);
							logger.info("RE-PROCESS_LOG : Record Re-processed Successfully.!! FOR PRID : "+processEntity.getPrId());
						}else {
							logger.info("RE-PROCESS_LOG : Record is not Re-processed..!! FOR PRID : "+processEntity.getPrId());
						}
						
					}else if(failedMethodName.equals("createCAPAFromMC")) {
						logger.info("RE-PROCESS_LOG : Method 'createCAPAFromMC' calling from Re-Process mechanism");
						int newChildPrId = impl.createCAPAFromMC(processEntity.getPrId(), sessionId, tws);
						if(newChildPrId>0) {
							updateProcessedRecord(id);
							logger.info("RE-PROCESS_LOG : Record Re-processed Successfully.!! FOR PRID : "+processEntity.getPrId());
						}else {
							logger.info("RE-PROCESS_LOG : Record is not Re-processed..!! FOR PRID : "+processEntity.getPrId());
						}
					}else if(failedMethodName.equals("createCAPAFROMRCI")) {
						logger.info("RE-PROCESS_LOG : Method 'createCAPAFROMRCI' calling from Re-Process mechanism");
						int newChildPrId = impl.createCAPAFROMRCI(processEntity.getPrId(), sessionId, tws);
						if(newChildPrId>0) {
							updateProcessedRecord(id);
							logger.info("RE-PROCESS_LOG : Record Re-processed Successfully.!! FOR PRID : "+processEntity.getPrId());
						}else {
							logger.info("RE-PROCESS_LOG : Record is not Re-processed..!! FOR PRID : "+processEntity.getPrId());
						}
					}else if(failedMethodName.equals("createInvActionChild")) {
						logger.info("RE-PROCESS_LOG : Method 'createInvActionChild' calling from Re-Process mechanism");
						int newChildPrId = impl.createInvActionChild(processEntity.getPrId(), sessionId, tws);
						if(newChildPrId>0) {
							updateProcessedRecord(id);
							logger.info("RE-PROCESS_LOG : Record Re-processed Successfully.!! FOR PRID : "+processEntity.getPrId());
						}else {
							logger.info("RE-PROCESS_LOG : Record is not Re-processed..!! FOR PRID : "+processEntity.getPrId());
						}
					}else if(failedMethodName.equals("setMetaDataForMCFormulation")) {
						logger.info("RE-PROCESS_LOG : Method 'setMetaDataForMCFormulation' calling from Re-Process mechanism");
						boolean isUpdated = impl.setMetaDataForMCFormulation(processEntity.getPrId(), sessionId, tws);
						if(isUpdated) {
							updateProcessedRecord(id);
							logger.info("RE-PROCESS_LOG : Record Re-processed Successfully.!! FOR PRID : "+processEntity.getPrId());
						}else {
							logger.info("RE-PROCESS_LOG : Record is not Re-processed..!! FOR PRID : "+processEntity.getPrId());
						}
					}else if(failedMethodName.equals("setOriginatingDept")) {
						logger.info("RE-PROCESS_LOG : Method 'setOriginatingDept' calling from Re-Process mechanism");
						boolean isUpdated = impl.setOriginatingDept(processEntity.getPrId(), sessionId, tws);
						if(isUpdated) {
							updateProcessedRecord(id);
							logger.info("RE-PROCESS_LOG : Record Re-processed Successfully.!! FOR PRID : "+processEntity.getPrId());
						}else {
							logger.info("RE-PROCESS_LOG : Record is not Re-processed..!! FOR PRID : "+processEntity.getPrId());
						}
					}else if(failedMethodName.equals("createCFTChild")) {
						logger.info("RE-PROCESS_LOG : Method 'createCFTChild' calling from Re-Process mechanism");
						int newChildPrId = impl.createCFTChild(processEntity.getPrId(), sessionId, tws);
						if(newChildPrId>0) {
							updateProcessedRecord(id);
						}else {
							logger.info("RE-PROCESS_LOG : Record is not Re-processed..!! FOR PRID : "+processEntity.getPrId());
						}
					}else if(failedMethodName.equals("createRAAssessChild")) {
						logger.info("RE-PROCESS_LOG : Method 'createRAAssessChild' calling from Re-Process mechanism");
						int newChildPrId = impl.createRAAssessChild(processEntity.getPrId(), sessionId, tws);
						if(newChildPrId>0) {
							updateProcessedRecord(id);
							logger.info("RE-PROCESS_LOG : Record Re-processed Successfully.!! FOR PRID : "+processEntity.getPrId());
						}else {
							logger.info("RE-PROCESS_LOG : Record is not Re-processed..!! FOR PRID : "+processEntity.getPrId());
						}
					}else if(failedMethodName.equals("createAIChild")) {
						logger.info("RE-PROCESS_LOG : Method 'createAIChild' calling from Re-Process mechanism");
						int newChildPrId = impl.createAIChild(processEntity.getPrId(), sessionId, tws);
						if(newChildPrId>0) {
							updateProcessedRecord(id);
							logger.info("RE-PROCESS_LOG : Record Re-processed Successfully.!! FOR PRID : "+processEntity.getPrId());
						}else {
							logger.info("RE-PROCESS_LOG : Record is not Re-processed..!! FOR PRID : "+processEntity.getPrId());
						}
					}else if(failedMethodName.equals("createAdditionalAIChild")) {
						logger.info("RE-PROCESS_LOG : Method 'createAdditionalAIChild' calling from Re-Process mechanism");
						int newChildPrId = impl.createAdditionalAIChild(processEntity.getPrId(), sessionId, tws);
						if(newChildPrId>0) {
							updateProcessedRecord(id);
							logger.info("RE-PROCESS_LOG : Record Re-processed Successfully.!! FOR PRID : "+processEntity.getPrId());
						}else {
							logger.info("RE-PROCESS_LOG : Record is not Re-processed..!! FOR PRID : "+processEntity.getPrId());
						}
					}else if(failedMethodName.equals("copyChildGridToParent")) {
						logger.info("RE-PROCESS_LOG : Method 'copyChildGridToParent' calling from Re-Process mechanism");
						boolean isUpdated = impl.copyChildGridToParent(processEntity.getPrId(), sessionId, tws);
						if(isUpdated) {
							updateProcessedRecord(id);
							logger.info("RE-PROCESS_LOG : Record Re-processed Successfully.!! FOR PRID : "+processEntity.getPrId());
						}else {
							logger.info("RE-PROCESS_LOG : Record is not Re-processed..!! FOR PRID : "+processEntity.getPrId());
						}
					}
				}
			}else {
				logger.info("RE-PROCESS_LOG : There is no any pending record for Re-Process.!!!");
			}
			
		}catch(Exception e) {
			logger.info("RE-PROCESS_LOG : Exception Occurred.!!"+e.getMessage());
		}finally {
			if(sessionId != null) {
				data.closeSession(sessionId);
				logger.info("RE-PROCESS_LOG : Session Id Closed form Re-Process Mechanism.!!");
			}else {
				logger.info("RE-PROCESS_LOG : There is no any live session Id.!!");
			}
		}
		
	}
	
	
	public static void updateProcessedRecord(int id) {
		logger.info("RE-PROCESS_LOG : ENTER IN METHOD updateProcessedRecord");
		try {
			RecordReprocessEntity recordEntity = RecordReprocessImple.getInstance().findById(id);
			recordEntity.setIsProcessed(1);
			RecordReprocessImple.getInstance().updateProcessedRecord(recordEntity);
		}catch(Exception e) {
			e.printStackTrace();
			logger.info("RE-PROCESS_LOG : Exception Occurred in updateProcessedRecord MSG:"+e.getMessage());
		}
		logger.info("RE-PROCESS_LOG : EXIT FROM METHOD updateProcessedRecord");
	}

}
